/*
** numeric.h
**
** Contains all numeric RAW's for messages/replies
*/

#ifndef __NUMERIC_H__
#define __NUMERIC_H__

/* Misc defines */
#define STOP_PARSING 1

/* Error messages */
#define ERROR_001			"ERROR :Closing Link: %s[%s] 001 (No Authorization)"
#define ERROR_002			"ERROR :Closing Link: %s[%s] 002 (No IRC clients permitted)"
#define ERROR_003			"ERROR :Closing Link: %s[%s] 003 (No more connections)"
#define ERROR_004			"ERROR :Closing Link: %s[%s] 004 (No new connections permitted)"
#define ERROR_005			"ERROR :Closing Link: %s[%s] 005 (Server shutdown by operator)"
#define ERROR_006			"ERROR :Closing Link: %s[%s] 006 (Reverse DNS lookup failed)"
#define ERROR_007			"ERROR :Closing Link: %s[%s] 007 (Killed by system operator)"
#define ERROR_008			"ERROR :Closing Link: %s[%s] 008 (Input flooding)"
#define ERROR_009			"ERROR :Closing Link: %s[%s] 009 (Output Saturation)"
#define ERROR_010			"ERROR :Closing Link: %s[%s] 010 (Quote exceeded)"
#define ERROR_011			"ERROR :Closing Link: %s[%s] 011 (Ping timeout)"
#define ERROR_012			"ERROR :Closing Link: %s[%s] 012 (Too many connections from your IP)"
#define ERROR_013			"ERROR :Closing Link: %s[%s] 013 (Out of resources)"

/* RAW numerics */
#define		RPL_WELCOME				001
#define		RPL_YOURHOST			002
#define		RPL_CREATED				003
#define		RPL_MYINFO				004

#define		RPL_UMODEIS				221

#define		RPL_LUSERCLIENT			251
#define		RPL_LUSEROP				252
#define		RPL_LUSERUNKNOWN		253
#define		RPL_LUSERCHANNELS		254
#define		RPL_LUSERME				255
#define		RPL_LOCALUSERS			265
#define		RPL_GLOBALUSERS			266

#define		RPL_WHOISUSER			311
#define		RPL_WHOISSERVER			312
#define		RPL_WHOISOPERATOR		313
#define		RPL_WHOISIDLE			317
#define		RPL_ENDOFWHOIS			318
#define		RPL_WHOISCHANNELS		319
#define		RPL_WHOISSPECIAL		320
#define		RPL_CHANNELMODEIS		324
#define		RPL_VERSION				351
#define		RPL_NAMREPLY			353
#define		RPL_ENDOFNAMES			366

#define		ERR_NOSUCHNICK			401
#define		ERR_NOSUCHCHANNEL		403
#define		ERR_CANNOTSENDTOCHAN	404
#define		ERR_NORECIPIENT			411
#define		ERR_NOTEXTTOSEND		412
#define		ERR_UNKNOWNCOMMAND		421
#define		ERR_NOMOTD				422
#define		ERR_NONICKNAMEGIVEN		431
#define		ERR_ERRONEUSNICKNAME	432
#define		ERR_NICKNAMEINUSE		433
#define		ERR_NOTONCHANNEL		442
#define		ERR_NOTREGISTERED		451
#define		ERR_NEEDMOREPARAMS		461
#define		ERR_ALREADYREGISTRED	462
#define		ERR_CHANOPRIVSNEEDED	482
#define		ERR_UNIQOPPRIVSNEEDED	485

#define		ERR_UMODEUNKNOWNFLAG	501
#define		ERR_USERSDONTMATCH		502

#define		IRCRPL_IRCX				800

#endif		/* __NUMERIC_H__ */