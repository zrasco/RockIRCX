/*
** client.cpp
**
** This file contains all the code for working with clients(connections to server).
** It contains nothing specific for users or servers, just the basic connection info.
*/

#include "client.h"

/* Global variables */
char recvbuf[8192];
#define MAX_ACCEPTS 100
HASH_TABLE_STRUCT	HT_User;
HASH_TABLE_STRUCT	HT_Server;
HASH_TABLE_STRUCT	HT_Channel;

void Client_AcceptNew(SOCKET fdListener)
/*
** Client_AcceptNew()
** Checks all bound server sockets for new connections, and handles them accordingly
*/
{
	int sindex = 0, localindex, slen = sizeof(struct sockaddr);
	SOCKET s;
	LINKED_LIST_STRUCT llNewConnections, *curr = &llNewConnections;
	CLIENT_STRUCT *csnew;
	int l_len = sizeof(struct sockaddr);
	struct sockaddr_in sin, l_sin;

	memset(&llNewConnections,0,sizeof(llNewConnections));

	while ((s = accept(fdListener,(struct sockaddr*)&sin,&slen)) != INVALID_SOCKET)
	/* Get all connections queued in the backlog */
	{
		scs.lusers.nUnknown++;

		/* For performance reasons, we will manually add connections to the list */
		curr->next = (LINKED_LIST_STRUCT*)calloc(1,sizeof(LINKED_LIST_STRUCT));
		curr = curr->next;

		curr->data = (void*)s;
	}

	/* Start at beginning of list again */
	curr = &llNewConnections;

	while (curr->next)
	/* Process all accepted connections */
	{
		curr = curr->next;

		l_len = sizeof(struct sockaddr);
		s = (SOCKET)curr->data;
		localindex = (int)s;

		if (s > scs.fdHighest)
			scs.fdHighest = s;

		csnew = scs.CSLocal[localindex] = (CLIENT_STRUCT*)calloc(1,sizeof(CLIENT_STRUCT));

		getpeername(s,(struct sockaddr*)&sin,&slen);

		/* IP/socket info */
		csnew->fd = (int)s;
		csnew->port_r = ntohs(sin.sin_port);
		csnew->ip = sin.sin_addr.s_addr;
		csnew->hops = 1;

		/* Server info */
		csnew->servernext = scs.sclient;
		strcpy(csnew->servername,scs.sclient->server->name);
        csnew->serverkey = scs.skey;

		/* Get info for listener, in this case the local port */
		getsockname(fdListener,(struct sockaddr*)&l_sin,&l_len);
		csnew->port_l = ntohs(l_sin.sin_port);

		if (SettingsInfo.isGeneral.dns_lookup)
		/* Initiate lookup */
		{
			Client_SendToOne(csnew,FALSE,":%s NOTICE AUTH :*** Looking up hostname...",SettingsInfo.isGeneral.servername);
			csnew->state = CLIENT_STATE_LOOKUP;
			Lookup_Perform(sin.sin_addr.s_addr,csnew);
		}
		else
		/* Use IP address as hostname */
		{
			strcpy(csnew->hostname,inet_ntoa(sin.sin_addr));
			csnew->state = CLIENT_STATE_REGISTERING;
		}

		/* Each client is a user until proven otherwise */
		csnew->user = (USER_STRUCT*)calloc(1,sizeof(USER_STRUCT));
	}

	/* Clear new connections list */
	while (llNewConnections.next)
		LL_Remove(&llNewConnections,llNewConnections.next->data);
}

void Client_Disconnect(CLIENT_STRUCT *client)
/*
** Client_Disconnect()
** Abruptly disconnects the target client from the network
** NOTE: This function can be called for any clients on the network
*/
{
	if (Client_IsLocal(client))
	{
		shutdown(client->fd,2);
		closesocket(client->fd);

		scs.CSLocal[client->fd] = NULL;

		if (Client_Registered(client))
		{
			LINKED_LIST_STRUCT *llChannel = (LINKED_LIST_STRUCT*)(&client->user->llChannelHead);
			CHANNEL_STRUCT *chTarget;
			scs.lusers.nLocalUsers--;

			/* Remove user from all channels they are in */
			while (client->user->llChannelHead.next)
			{
				chTarget = (CHANNEL_STRUCT*)client->user->llChannelHead.next->data;
				Channel_DeleteUser(chTarget,client);

				if (chTarget->dwUsers < 1)
					Channel_Cleanup(chTarget);
			}
		}
		else
			scs.lusers.nUnknown--;

		if (Client_IsServer(client))
		{
			Serverlist_ChangeStatus(client->server->name,FALSE);
			scs.lusers.nLocalServers--;
		}
	}

	/* Update luser counts */
	if (Client_Registered(client))
		scs.lusers.nGlobalUsers--;
	if (Client_IsPriveledged(client))
		scs.lusers.nOpsOnline--;
	if (Client_Invisible(client))
		scs.lusers.nInvisible--;


	if (Client_IsServer(client))
	{
		Hash_Delete(&HT_Server,client->server->name,client);
		scs.lusers.nGlobalServers--;
	}
	else
		Hash_Delete(&HT_User,client->user->nickname,client);

	Client_Destroy(client);
}


void Client_Destroy(CLIENT_STRUCT *client)
/*
** Client_Destroy()
** This function clears and deallocates a client structure
** NOTE: This function is to be used for cleaning-up purposes only...
*/
{
	if (Client_IsServer(client))
		free(client->server);
	else
		free(client->user);

	StrBuf_Empty(&client->recvQ);
	StrBuf_Empty(&client->sendQ);

	if (client->quitmessage)
		free(client->quitmessage);

	free(client);
	client = NULL;
}

void Client_SendError(CLIENT_STRUCT *client, BOOL bCloseOnSend, const char *string, ...)
/*
** Client_SendError()
** This function sends an ERROR message to the specified client
*/
{
	va_list vArgs;
	char errbuf[512];
	char buf[256];

	va_start(vArgs,string);
	vsprintf(buf,string,vArgs);
	va_end(vArgs);

	sprintf(errbuf,"%s ERROR: %s",Client_Nickname(client),buf);

	strcat(errbuf,"\r\n");

	StrBuf_Add(&client->sendQ,buf,(int)strlen(buf));

	if (bCloseOnSend)
		client->flags |= CLIENT_FLAG_CLOSEONSEND;
}

void Client_SendErrorNumber(CLIENT_STRUCT *client, BOOL bCloseOnSend, const char *errstr)
/*
** Client_SendErrorNumber()
**
** This function sends a "ERROR: Closing Link:" message to the target client
** NOTE: errstr MUST be one of the ERROR_XXX constants defined in numeric.h
*/
{
	char buf[1024];
	struct in_addr in;

	in.s_addr = client->ip;

	sprintf(buf,errstr,Client_Nickname(client),inet_ntoa(in));
	strcat(buf,"\r\n");

	StrBuf_Add(&client->sendQ,buf,(int)strlen(buf));

	if (bCloseOnSend)
		client->flags |= CLIENT_FLAG_CLOSEONSEND;
}

void Client_SendToOne(CLIENT_STRUCT *client,BOOL bCloseOnSend, const char *string, ...)
/*
** Client_SendToOne()
** This function will "send" a CRLF-terminated message to the target client
** (It works by adding it to the end of the send buffer)
*/
{
	va_list vArgs;
	char buf[1024];

	if (!Client_IsLocal(client))
		return;

	va_start(vArgs,string);
	vsprintf(buf,string,vArgs);
	va_end(vArgs);

	strcat(buf,"\r\n");

	StrBuf_Add(&client->sendQ,buf,(int)strlen(buf));

	if (bCloseOnSend)
		client->flags |= CLIENT_FLAG_CLOSEONSEND;
}

void Client_SendLusers(CLIENT_STRUCT *client)
/*
** Client_SendLusers()
** Sends all lusers numerics to the specified client
*/
{
	char buffer[1024];
	
	Client_SendToOne(client,FALSE,":%s %3.3d %s :There are %d users and %d invisible on %d servers",
		SettingsInfo.isGeneral.servername,RPL_LUSERCLIENT,Client_Nickname(client),scs.lusers.nGlobalUsers,scs.lusers.nInvisible,scs.lusers.nGlobalServers);

	if (scs.lusers.nOpsOnline)
		Client_SendToOne(client,FALSE,":%s %3.3d %s %d :operator(s) online",
		SettingsInfo.isGeneral.servername,RPL_LUSEROP,Client_Nickname(client),scs.lusers.nOpsOnline);

	if (scs.lusers.nUnknown)
		Client_SendToOne(client,FALSE,":%s %3.3d %s %d :unknown connection(s)",
		SettingsInfo.isGeneral.servername,RPL_LUSERUNKNOWN,Client_Nickname(client),scs.lusers.nUnknown);

	if (scs.lusers.nChannels)
		Client_SendToOne(client,FALSE,":%s %3.3d %s %d :channels formed",
		SettingsInfo.isGeneral.servername,RPL_LUSERCHANNELS,Client_Nickname(client),scs.lusers.nChannels);

	Client_SendToOne(client,FALSE,":%s %3.3d %s :I have %d clients and %d servers",
		SettingsInfo.isGeneral.servername,RPL_LUSERME,Client_Nickname(client),scs.lusers.nLocalUsers,scs.lusers.nLocalServers);
	Client_SendToOne(client,FALSE,":%s %3.3d %s :Current local users: %d Max: %d",
		SettingsInfo.isGeneral.servername,RPL_LOCALUSERS,Client_Nickname(client),scs.lusers.nLocalUsers,scs.lusers.nLocalMax);
	Client_SendToOne(client,FALSE,":%s %3.3d %s :Current global users: %d Max: %d",
		SettingsInfo.isGeneral.servername,RPL_GLOBALUSERS,Client_Nickname(client),scs.lusers.nGlobalUsers,scs.lusers.nGlobalMax);
}

void Client_SendWelcome(CLIENT_STRUCT *client)
/*
** Client_SendWelcome()
** Sends numerics 001-004 to the target client, which are sent to all connecting
*/
{
	char *buffer = NULL;	

	if (Client_IsUser(client))
	/* Send user greeting */
	{
		char *usermodes = "aioxz";
		char *channelmodes = "abhiklmnoprstuwx";


		/* Since we only do this once, update our lusers count */
		scs.lusers.nUnknown--; scs.lusers.nLocalUsers++; scs.lusers.nGlobalUsers++;

		if (scs.lusers.nLocalUsers > scs.lusers.nLocalMax)
			scs.lusers.nLocalMax = scs.lusers.nLocalUsers;

		if (scs.lusers.nGlobalUsers > scs.lusers.nGlobalMax)
			scs.lusers.nGlobalMax = scs.lusers.nGlobalUsers;

		buffer = (char*)calloc(1,4096);

		sprintf(buffer,
			":%s %3.3d %s :Welcome to the %s %s" CRLF
			":%s %3.3d %s :Your host is %s, running version " ROCKIRCX_VERSION CRLF
			":%s %3.3d %s :This server was created " ROCKIRCX_CREATED CRLF
			":%s %3.3d %s %s " ROCKIRCX_VERSION " %s %s" CRLF,
			SettingsInfo.isGeneral.servername,RPL_WELCOME,client->user->nickname,SettingsInfo.isGeneral.serverdescription,client->user->nickname,
			SettingsInfo.isGeneral.servername,RPL_YOURHOST,client->user->nickname,SettingsInfo.isGeneral.servername,
			SettingsInfo.isGeneral.servername,RPL_CREATED,client->user->nickname,
			SettingsInfo.isGeneral.servername,RPL_MYINFO,client->user->nickname,SettingsInfo.isGeneral.servername,usermodes,channelmodes);

	}
	else if (Client_IsServer(client))
	/* Send server greeting */
	/* TEMP: Make sure server which is doing the connecting sends this?? */
	{
		char sub_buf[1024], szMode[64], szNameslist[32768];
		int count, count2;
		LINKED_LIST_STRUCT *curr ,*llChannel = &(scs.llChannelHead);
		CLIENT_STRUCT *c_info, *c_server, *c_target;
		CHANNEL_STRUCT *chChannel = NULL;

		buffer = (char*)calloc(16,4096);

		/* Step #1: Send SPASS command */
		sprintf(buffer,MSG_SPASS " %s %s %s %s\r\n",client->password,SettingsInfo.isGeneral.networkname,SettingsInfo.isGeneral.servername,ROCKIRCX_PROTOCOL_VERSION);

		/* Step #2: Send all known server information */

		/* Step #2a: Send information about this server */

		sprintf(sub_buf,":%s " TOK_SERVER " %s 0 %d :%s\r\n",scs.sclient->server->name,scs.sclient->server->name,scs.sclient->server->id,scs.sclient->server->description);
		strcat(buffer,sub_buf);

		/* Step #2b: Send information about all other known servers */
		for (count = 0; count < MAX_HOPS; count++)
		/* Read servers from linked lists(referenced by the number of hops) */
		{
			curr = &scs.llServerHead[count];

			while (curr->next)
			/* Get next server which is <count> hops away */
			{
				curr = curr->next;

				c_info = (CLIENT_STRUCT*)curr->data;

				sprintf(sub_buf,":%d " TOK_SERVER " %s %d %d :%s\r\n",scs.sclient->server->id,c_info->server->name,c_info->hops,c_info->server->id,c_info->server->description);
				strcat(buffer,sub_buf);
			}
		}

		/* No more servers to send */
		sprintf(sub_buf,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		strcat(buffer,sub_buf);

		for (count = 0; count < MAX_HOPS; count++)
		/* Step #3: Send all known user information */
		{
			curr = &scs.llUserHead[count];

			while (curr->next)
			{
				/* Get next user */
				curr = curr->next;
				c_target = (CLIENT_STRUCT*)curr->data;
				c_server = User_GetServer(c_target);

				if (c_target->servernext != client)
				/* They already know about this user!! */
				{
					sprintf(sub_buf,":%s " TOK_USERDATA " %s %d %s %s %d %s :%s\r\n",
						c_server->server->name,
						c_target->user->nickname,
						c_target->hops,
						c_target->user->username,
						c_target->hostname,
						c_server->server->id,
						"temp",
						c_target->user->fullname);

					strcat(buffer,sub_buf);
				}
			}
		}

		/* No more users to send */
		sprintf(sub_buf,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		strcat(buffer,sub_buf);

		/* Step #4: Send all known channel information */
		while (llChannel->next)
		{
			llChannel = llChannel->next;

			chChannel = (CHANNEL_STRUCT*)(llChannel->data);

			/* Get our modes and names list for our NJOIN message */
			Channel_GetModeString(chChannel,szMode);
			Channel_CreateUserlist(chChannel,szNameslist,sizeof(szNameslist));

			sprintf(sub_buf,":%s " TOK_NJOIN " %s %d %s %d :%s" CRLF,
				scs.sclient->server->name,
				chChannel->szName,
				chChannel->dwPropCreationTime,
				szMode,
				chChannel->dwLimit,
				szNameslist);

			/* TODO: Send all PROP and ACCESS entries */
			strcat(buffer,sub_buf);
		}

		/* No more channels to send */
		sprintf(sub_buf,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		strcat(buffer,sub_buf);



	}

	/* Set sign-on time */
	client->signon = time(NULL);

	/* Mask the IP address */
	strcpy(client->hostmask,client->hostname);

	StrBuf_Add(&client->sendQ,buffer,(int)strlen(buffer));
	free(buffer);
}

void Client_SendMOTD(CLIENT_STRUCT *client)
/*
** Client_SendMOTD()
** Sends the MOTD & numerics to the specified client
*/
{
	/* TEMP: No MOTD for now */
	Client_SendNumericToOne(client,ERR_NOMOTD,NULL);
}

void Client_SendList(CLIENT_STRUCT *client, BOOL bListX, const char *szParameters)
/*
** Client_SendList()
** Sends a list of channels to the client specified
*/
{
	CHANNEL_STRUCT *chChannel = NULL;
	LINKED_LIST_STRUCT *llChannel = NULL;

	if (bListX == TRUE)
		Client_SendToOne(client,FALSE,":%s %3.3d %s :Start of ListX",SettingsInfo.isGeneral.servername,811,Client_Nickname(client));
	else
		Client_SendToOne(client,FALSE,":%s %3.3d %s Channel :Users	Name",SettingsInfo.isGeneral.servername,321,Client_Nickname(client));

	llChannel = &scs.llChannelHead;

	while (llChannel->next != NULL)
	/* Loop through channels and add them to the list */
	{
		char szBuffer[256];

		llChannel = llChannel->next;

		chChannel = (CHANNEL_STRUCT*)(llChannel->data);
		Channel_GetModeString(chChannel,szBuffer);

		/* Check channel permissions here */
		/* TEMP: Output all channels */

		if (bListX == TRUE)
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s %s %d 0 :%s",SettingsInfo.isGeneral.servername,812,Client_Nickname(client),chChannel->szName,szBuffer,chChannel->dwUsers,chChannel->szPropTopic);
		else
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s %d :%s",SettingsInfo.isGeneral.servername,322,Client_Nickname(client),chChannel->szName,chChannel->dwUsers,chChannel->szPropTopic);
	}

	if (bListX == TRUE)
		Client_SendToOne(client,FALSE,":%s %3.3d %s :End of ListX",SettingsInfo.isGeneral.servername,817,Client_Nickname(client));
	else
		Client_SendToOne(client,FALSE,":%s %3.3d %s :End of /LIST",SettingsInfo.isGeneral.servername,323,Client_Nickname(client));
}

void Client_SendNumericToOne(CLIENT_STRUCT *client, int numeric, const char *data)
/*
** Client_SendNumericToOne()
** Sends a RAW numeric to the specified client
*/
{
	switch (numeric)
	{
		case ERR_NOSUCHNICK:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :No such nick/channel",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NORECIPIENT:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :No recipient given (%s)",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NOTEXTTOSEND:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :No text to send (%s)",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_UNKNOWNCOMMAND:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :Unknown command",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NONICKNAMEGIVEN:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :No nickname given",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		case ERR_ERRONEUSNICKNAME:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :Erroneous nickname",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NICKNAMEINUSE:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :Nickname is already in use",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NOMOTD:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :MOTD File is missing",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		case ERR_NOTREGISTERED:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :You have not registered",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		case ERR_NEEDMOREPARAMS:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :Not enough parameters",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_ALREADYREGISTRED:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :You may not reregister",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		case RPL_VERSION:
			Client_SendToOne(client,FALSE,":%s %3.3d %s RockIRCX " ROCKIRCX_VERSION " %s :%s",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),SettingsInfo.isGeneral.servername,data);
		break;
		case RPL_ENDOFNAMES:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :End of /NAMES list",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case IRCRPL_IRCX:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %d 0 ANON %d *",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),client->user->bInIRCX,SettingsInfo.isSecurity.max_msglen);
		break;
		case ERR_NOSUCHCHANNEL:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :No such channel",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_USERSDONTMATCH:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :Cant change mode for other users",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		case RPL_CHANNELMODEIS:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_CANNOTSENDTOCHAN:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :Cannot send to channel",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_NOTONCHANNEL:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :You're not on that channel",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_CHANOPRIVSNEEDED:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :You're not channel operator",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_UNIQOPPRIVSNEEDED:
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :You're not channel owner",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
		case ERR_UMODEUNKNOWNFLAG:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :Unknown MODE flag",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client));
		break;
		default:
			Client_SendToOne(client,FALSE,":%s %3.3d %s :%s",SettingsInfo.isGeneral.servername,numeric,Client_Nickname(client),data);
		break;
	}
}

void Client_SendToAllLocal(BOOL bCloseOnSend, const char *string, ...)
/*
** Client_SendToAllLocal()
** This function will send a CRLF-terminated message to all local clients
*/
{
	va_list vArgs;
	char buf[1024];
	int count, len;
	CLIENT_STRUCT *client;

	va_start(vArgs,string);
	vsprintf(buf,string,vArgs);
	va_end(vArgs);

	strcat(buf,"\r\n");
	len = (int)strlen(buf);

	for (count = (int)scs.fdHighest; count >= 0; count--)
	{
		if (client = scs.CSLocal[count])
		/* Loop through all valid connections */
		{
			StrBuf_Add(&client->sendQ,buf,len);

			if (bCloseOnSend)
				client->flags |= CLIENT_FLAG_CLOSEONSEND;
		}

	}
}

void Client_FlushBuffer(CLIENT_STRUCT *client)
/*
** Client_FlushBuffer()
** This function sends all queued data to the client's socket
*/
{
	int retval;

	if ((client->flags & CLIENT_FLAG_CLOSEONSEND) && StrBuf_IsEmpty(&client->sendQ))
	/* Close connection & de-allocate structure */
		client->state = CLIENT_STATE_DEAD;
	else if (StrBuf_Length(&client->sendQ))
	{
		retval = send(client->fd,StrBuf_String(&client->sendQ),StrBuf_Length(&client->sendQ),0);

		if (retval == (signed)StrBuf_Length(&client->sendQ))
		/* Sent whole sendQ */
		{
			StrBuf_Empty(&client->sendQ);

			if (client->flags & CLIENT_FLAG_CLOSEONSEND)
				client->state = CLIENT_STATE_DEAD;

			//client->flags ^= CLIENT_FLAG_NEWLINE;
		}
		else if (retval != SOCKET_ERROR)
		/* Sent partial sendQ */
		{
			StrBuf_Delete(&client->sendQ,retval);
		}
		else
		/* Error in send */
		{
			client->state = CLIENT_STATE_DEAD;
		}

	}
}

int Client_ReadPacket(CLIENT_STRUCT* client, FD_SET *pread_set)
/*
** Client_ReadPacket()
** This function takes an incoming packet of data and handles all parsing, etc...
*/
{
	int length = 0, length2 = 0, sbl = StrBuf_Length(&client->recvQ);
	time_t currtime = GetTickCount();

	if (FD_ISSET(client->fd,pread_set) &&
		!(Client_IsUser(client) && ((unsigned long)sbl > SettingsInfo.isUser.max_recvq)))
	/* We have a user pending data which is still below the flood limit */
	{
		length = recv(client->fd,recvbuf,sizeof(recvbuf),0);

		client->lastmsg = currtime;

		if (client->lastmsg > client->parsemsg)
			client->parsemsg = client->lastmsg;

		if (length == SOCKET_ERROR && WSAGetLastError() == WSAEWOULDBLOCK)
		/* Not ready for reading yet */
			return 1;
		else if (length == SOCKET_ERROR)
		/* Error in reading of socket */
		{
			client->state = CLIENT_STATE_DEAD;
			return STOP_PARSING;
		}
		if (length <= 0)
			return length;

		/* Check to see if we have a newline(flag will be re-set appropriatley) */
		client->flags |= CLIENT_FLAG_NEWLINE;

		recvbuf[length] = 0;
	}

	if (length)
	/* Add data to RecvQ */
		StrBuf_Add(&client->recvQ,recvbuf,length);

	if (Client_IsServer(client))
	/* Immediatley process all server messages */
	{
        while (!StrBuf_IsEmpty(&client->recvQ) && Client_NewLine(client))
		{
			if (!StrBuf_IsEmpty(&client->recvQ))
			/* Get CRLF-terminated messages */
			{
				if (length2 = StrBuf_ReadCRLF(&client->recvQ,recvbuf,sizeof(recvbuf),FALSE))
				{
					client->flags |= CLIENT_FLAG_NEWLINE;

					if (Client_Parse(client,recvbuf,length2) == STOP_PARSING)
						return STOP_PARSING;
				}
				else
				{
					//client->flags ^= CLIENT_FLAG_NEWLINE;
					break;
				}
			}
		}
	}
	else
	/* Parse when the time is appropriate */
	{
		if (StrBuf_Length(&client->recvQ) > SettingsInfo.isUser.max_recvq)
		/* Floooooooood! */
		{
			Client_SendErrorNumber(client,TRUE,ERROR_008);
			return STOP_PARSING;
		}

		while (!StrBuf_IsEmpty(&client->recvQ) && Client_NewLine(client) &&
			(client->state != CLIENT_STATE_LOOKUP && (client->parsemsg - currtime) <= ((signed)SettingsInfo.isUser.msgdelay * CLIENT_MAXMESSAGEBURST)))
		/* If a client has no parse delay, (CLIENT_MAXMESSAGEBURST) messages are allowed */
		{

			if (!StrBuf_IsEmpty(&client->recvQ) && (length2 = StrBuf_ReadCRLF(&client->recvQ,recvbuf,sizeof(recvbuf),FALSE)))
			/* CRLF-terminated message is awaiting */
			{
				client->flags |= CLIENT_FLAG_NEWLINE;

				if (length2 > SettingsInfo.isSecurity.max_msglen)
				/* Message is too long, truncate */
				{
					length2 = SettingsInfo.isSecurity.max_msglen;
					recvbuf[length2 - 2] = '\r';
					recvbuf[length2 - 1] = '\n';
					recvbuf[length2] = 0;
				}

				if (Client_Parse(client,recvbuf,length2) == STOP_PARSING)
					return STOP_PARSING;
			}
			else
			{
				client->flags ^= CLIENT_FLAG_NEWLINE;
				break;
			}
		}
	}

	return 1;
}

int	Client_Parse(CLIENT_STRUCT *client, char *message, int length)
/*
** Client_Parse()
** Takes the message sent by a client and processes it
*/
{
	int count = 0, argc = 0;

	memset(&scs.msginfo,0,sizeof(scs.msginfo));

	/* Who is sending this message? */
	scs.msginfo.c_prefixfrom = scs.msginfo.c_from = client;

	while (count <= length)
	/* Break the passed message into tokens */
	{
		while (message[count] == ' ')
			count++;

		if (count >= length)
		/* We appear to have trailing spaces in message */
			break;

		scs.msginfo.argc = ++argc;

		if (message[count] != ':' || argc == 1)
		/* At beginning of next token */
		{
			scs.msginfo.argv[argc - 1] = &message[count];

			while (message[count] != ' ' && count <= length)
			/* Skip to end of message */
				count++;

			if (count == length)
				message[count] = 0;
			else
			/* We are at end of message */
				message[count++] = 0;
		}
		else
		/* The ':' has a special purpose...ex "PRIVMSG person :private message" */
		{
			scs.msginfo.argv[argc - 1] = &message[count + 1];

			/* End of message */
			message[length] = 0;
			break;
		}
	}

	/* We have successfully seperated the tokens and parameters, time to use them */
	return Message_Execute();
}

unsigned int Client_GetIdle(CLIENT_STRUCT *c_target)
/*
** Client_GetIdle()
** Returns the idle time of the client, in seconds
*/
{
	unsigned int retval = c_target->lastmsg;

	retval = GetTickCount() - retval;
	retval /= 1000;

	return retval;
}

int Client_GetWhoisChannels(CLIENT_STRUCT *csAsking, CLIENT_STRUCT *csTarget, char *pszOutputBuffer)
/*
** Client_GetWhoisChannels()
** Retrieves the list of channels to be displayed in the /whois
** Depends on a list of factors, including channel privacy modes, user modes, etc...
** Returns -1 if there are no channels to be displayed(for whatever reason)
*/
{
	char chbuf[1024];
	CHANNEL_STRUCT *chChannel = NULL;
	LINKED_LIST_STRUCT *llChannel = &(csTarget->user->llChannelHead);
	DWORD dwPriveledge = 0;
	BOOL bReturnMinusOne = TRUE;

	/* Ready our string for strcat's */
	chbuf[0] = 0;

	if (!llChannel->next)
	/* Target user is not on any channels! */
		return -1;
	else
	/* User is on channels */
	{
		while (llChannel->next)
		/* Loop through list of target user's channels */
		{
			/* Get our next channel */
			llChannel = llChannel->next;
			chChannel = (CHANNEL_STRUCT*)(llChannel->data);

			if ((Client_IsOnChannel(csTarget,chChannel,&dwPriveledge) && Client_IsOnChannel(csAsking,chChannel,NULL)) ||
				Client_IsAdmin(csAsking) || Client_IsSysop(csAsking) ||
				Channel_IsPublic(chChannel) || csAsking == csTarget)
			/*
			** Display channel only under these circumstances:
			** 1) The asking user and the target user are both on this channel
			** 2) Asking user is an administrator or sysop
			** 3) This channel is public(no +s, +p, or +h mode set)
			** 4) The user is doing a /whois on themselves
			*/
			{
				bReturnMinusOne = FALSE;

				if (dwPriveledge & CHANNEL_PRIVELEDGE_OWNER)
					strcat(chbuf,".");
				else if (dwPriveledge & CHANNEL_PRIVELEDGE_HOST)
					strcat(chbuf,"@");
				else if (dwPriveledge & CHANNEL_PRIVELEDGE_VOICE)
					strcat(chbuf,"+");

				strcat(chbuf,chChannel->szName);
				strcat(chbuf," ");
			}
		}
	}

	if (bReturnMinusOne)
		return -1;
	else
	/* Fill in the specified buffer */
	{
		chbuf[strlen(chbuf) - 1] = 0;
		strcpy(pszOutputBuffer,chbuf);
		return 0;
	}
}

BOOL Client_IsOnChannel(CLIENT_STRUCT *csUser, CHANNEL_STRUCT *chChannel, DWORD *pdwPriveledge)
/*
** Client_IsOnChannel()
** Does a check to see if the user is on the channel specified
** If pdwPriveledge is specified, the priveledge of the user will be written to it.
*/
{
	LINKED_LIST_STRUCT *llChannel = NULL;

	if (!pdwPriveledge)
	/* Quick check mode(look thru the user structure) */
	{
		llChannel = LL_Find(&(csUser->user->llChannelHead),chChannel);

		if (llChannel)
			return TRUE;
	}
	else
	/* Check thru channel list so we can also return the priveledge */
	{
		LINKED_LIST_STRUCT *llUser = &(chChannel->llUserHead);
		LINKED_LIST_STRUCT *llUserMode = &(chChannel->llUserModeHead);

		while (llUser->next)
		/* Go through the user list of this channel */
		{
			llUser = llUser->next;
			llUserMode = llUserMode->next;

			if (
				((CLIENT_STRUCT*)(llUser->data)) == csUser
				)
			/* Found our user! */
			{
				*pdwPriveledge = (DWORD)llUserMode->data;

				return TRUE;
			}
		}
	}

	return FALSE;
}

void Server_Broadcast(CLIENT_STRUCT *c_exclude_server, const char *message, ...)
/*
** Server_Broadcast()
** Broadcasts a message to all servers
** The c_exclude_server parameter is optional, and will broadcast to all servers except it.
*/
{
	LINKED_LIST_STRUCT *curr = NULL;
	CLIENT_STRUCT *c_server = NULL;
	va_list vArgs;
	char buf[2048];

	va_start(vArgs,message);
	vsprintf(buf,message,vArgs);
	va_end(vArgs);

	/* All our servers are one hop away */
	curr = &scs.llServerHead[1];

	while (curr->next)
	/* Go thru our servers and broadcast this! */
	{
		curr = curr->next;

		c_server = (CLIENT_STRUCT*)curr->data;

		if (c_server != c_exclude_server)
		/* Broadcast this message but skip c_exclude_server */
			Client_SendToOne(c_server,FALSE,buf);
	}

}

void Server_BroadcastFromUser(CLIENT_STRUCT *csUser, const char *message, ...)
/*
** Server_BroadcastFromUser()
** Broadcasts a message to all servers, but with the syntax like Channel_BroadcastToAllLocal()
** Sends message in all directions except the link leading to csUser.
*/
{
	LINKED_LIST_STRUCT *curr = NULL;
	CLIENT_STRUCT *c_server = NULL;
	va_list vArgs;
	char buf[2048];

	va_start(vArgs,message);
	vsprintf(buf,message,vArgs);
	va_end(vArgs);

	/* All our servers are one hop away */
	curr = &scs.llServerHead[1];

	while (curr->next)
	/* Go thru our servers and broadcast this! */
	{
		curr = curr->next;

		c_server = (CLIENT_STRUCT*)curr->data;

		if (c_server != csUser->servernext)
		/* Broadcast this message but skip c_exclude_server */
			Client_SendToOne(c_server,FALSE,":%s!~%s@%s %s",csUser->user->nickname,csUser->user->username,csUser->hostname,buf);
	}

}

CLIENT_STRUCT *User_GetServer(CLIENT_STRUCT *c_user)
/*
** User_GetServer()
** This function returns the server information for the user specified.
*/
{
	CLIENT_STRUCT *cret = NULL;

	cret = (CLIENT_STRUCT*)(HT_Server.HashEntry[c_user->serverkey]->chainhead.next->data);
    
	return cret;
}

CLIENT_STRUCT *User_Find(const char *nickname)
/*
** User_Find()
** Finds the user structure with the nickname specified
** Returns: NULL if nickname not found, or pointer to client with nickname
*/
{
	CLIENT_STRUCT *cret = NULL, *client = NULL;
	HASH_FIND_STRUCT FindInfo;
	LINKED_LIST_STRUCT *curr = NULL;

	/* Find our user in the hash table */
	FindInfo.textkey = nickname;
	FindInfo.data = NULL;

	Hash_Find(&HT_User,&FindInfo,HASH_NOKEY);

	if (FindInfo.found)
	/* The nickname possibly exists */
	{
		curr = &(FindInfo.found->chainhead);

		while (curr->next)
		{
			curr = curr->next;

			client = (CLIENT_STRUCT*)curr->data;

			if (stricmp(nickname,client->user->nickname) == 0)
			/* Nickname has been found */
			{
				cret = client;
				break;
			}
		}
	}

	return cret;
}

void Parse_UserList(const char *szUserList, LINKED_LIST_STRUCT *llUserHead)
/*
** Parse_UserList()
** Takes a list of users and puts them in the specified linked list.
** Any users which do not exist will be placed in the list as the value NULL
** Any parameters specified as "*" will have entries with the value USER_ALLUSERS returned
*/
{
	CLIENT_STRUCT *csUser = NULL;

	int count, tokens = numtok(szUserList,',');
	char userbuf[512];

	llUserHead->data = NULL; llUserHead->next = NULL;

	for (count = 1; count <= tokens; count++)
	/* Loop through the channels seperated by commas */
	{
		csUser = User_Find(gettok(userbuf,szUserList,count,','));

		if (userbuf[0] == '*' && userbuf[1] == 0)
		/* Targeting all users */
			LL_AddNoCheck(llUserHead,(void*)USER_ALLUSERS);
		else if (csUser == NULL)
		/* User is invalid */
			LL_AddNoCheck(llUserHead,NULL);
		else
		/* User is valid(but we dont wan't duplicate entries) */
			LL_Add(llUserHead,(void*)csUser);
	}
}

CLIENT_STRUCT *Server_HashFind(const char *servername)
/*
** Server_HashFind()
** Finds the server client structure with the name specified
** Returns: NULL if server not found, or pointer to client containing server with name
*/
{
	CLIENT_STRUCT *cret = NULL, *client = NULL;
	HASH_FIND_STRUCT FindInfo;
	LINKED_LIST_STRUCT *curr = NULL;

	/* Find our server in the hash table */
	FindInfo.textkey = servername;
	FindInfo.data = NULL;

	Hash_Find(&HT_Server,&FindInfo,HASH_NOKEY);

	if (FindInfo.found)
	/* The server possibly exists */
	{
		curr = &(FindInfo.found->chainhead);

		while (curr->next)
		{
			curr = curr->next;

			client = (CLIENT_STRUCT*)curr->data;

			if (stricmp(servername,client->server->name) == 0)
			/* Server has been found */
			{
				cret = client;
				break;
			}
		}
	}

	return cret;
}

void User_GetModeString(CLIENT_STRUCT *client, char *pszStringOutput, BOOL bOmitGagMode)
/*
** User_GetModeString()
** Retrieves the modes for the specified user
*/
{
	int nIndex = 0;

	pszStringOutput[nIndex] = 0;

	if (Client_IsAdmin(client))
		pszStringOutput[nIndex++] = 'a';
	if (Client_IsSysop(client))
		pszStringOutput[nIndex++] = 'o';
	if (Client_Invisible(client))
		pszStringOutput[nIndex++] = 'i';
	if (client->user->bInIRCX == TRUE)
		pszStringOutput[nIndex++] = 'x';
	if (Client_IsGagged(client) && bOmitGagMode == FALSE)
		pszStringOutput[nIndex++] = 'z';
	
	pszStringOutput[nIndex] = 0;
}

int User_GetCommonChannels(CLIENT_STRUCT *client, CLIENT_STRUCT *csTarget, char *szChannelBuffer, LINKED_LIST_STRUCT *llChannelHead)
/*
** User_GetCommonChannels()
** Fills the output buffer (optional, pass NULL if not needed) and returns the # of common channels between two users
*/
{
	LINKED_LIST_STRUCT *llCH_Client = &(client->user->llChannelHead);
	LINKED_LIST_STRUCT *llCH_Target = NULL;

	int nCount = 0;

	if (szChannelBuffer)
		szChannelBuffer[0] = 0;

	/* Loop through channels of "requesting user" */
	while (llCH_Client->next)
	{
		llCH_Client = llCH_Client->next;

		llCH_Target = LL_Find(&(csTarget->user->llChannelHead),llCH_Client->data);

		if (llCH_Target)
		/* Common channel found */
		{
			nCount++;

			if (szChannelBuffer)
			/* Add to optional buffer */
			{
				strcat(szChannelBuffer,((CHANNEL_STRUCT*)(llCH_Target->data))->szName);
				strcat(szChannelBuffer," ");
			}
			if (llChannelHead)
			/* Add to optional linked list */
				LL_Add(llChannelHead,llCH_Target->data);
		}
	}

	if (nCount > 0 && szChannelBuffer)
	/* Cut off trailing space */
		szChannelBuffer[strlen(szChannelBuffer) - 1] = 0;

	return nCount;
}

void User_BroadcastToAllLocalsInAllChannels(CLIENT_STRUCT *csUser, CLIENT_STRUCT *csExcludeUser, char *szMessage, ...)
/*
** User_BroadcastToAllLocalsInAllChannels()
** The function name is long enough to say what it does!
** It simply calls Channel_BroadcastToLocal for all channels for the specified user
*/
{
	va_list vArgs;
	char buf[2048];
	DWORD dwPriveledge = 0;

	LINKED_LIST_STRUCT *llChannel = &(csUser->user->llChannelHead);
	LINKED_LIST_STRUCT *llUser = &(scs.llUserHead);
	CLIENT_STRUCT *csUserLoop = NULL;

	va_start(vArgs,szMessage);
	vsprintf(buf,szMessage,vArgs);
	va_end(vArgs);

	while (llUser->next)
	/* Loop through all users and if a common channel is shared, broadcast the message */
	{
		llUser = llUser->next;

		csUserLoop = (CLIENT_STRUCT*)(llUser->data);

		if (csUserLoop != csExcludeUser && User_GetCommonChannels(csUser,csUserLoop,NULL,NULL) > 0)
		/* Send the message! */
		{
			/* Determine highest priveledge level the target user shares in a common channel with source user */
			if (User_DoWeMask(csUser,csUserLoop))
			/* Send message masked */
			else
			/* Send message unmasked */
		}

	}
}

BOOL User_DoWeMask(CLIENT_STRUCT *csFrom, CLIENT_STRUCT *csTo)
/*
** User_GetMaskLevel()
** Determines wether a message sent from one user(csFrom) to another (csTo) should be masked.
** Returns TRUE if the message is to be masked, FALSE if the message is to be sent free and clear
*/
{
	LINKED_LIST_STRUCT llChannelHead;
	LINKED_LIST_STRUCT *llChannel = &llChannelHead;

	llChannel->data = NULL;
	llChannel->next = NULL;

	if (Client_IsPriveledged(csTo))
		return FALSE;

	if (Client_GetWhoisChannels(csFrom,csTo,NULL,llChannel) > 0)
	/* Determine if the "to" user is a host/owner in any of the channels the "from" user is in */
	{

		LL_Clear(llChannel);
	}

	return TRUE;
}