/*
** messages.cpp
**
** This file handles all message processing for the server
*/

#include "messages.h"

/* Create message table & lookup table */
Message *MessageMap[MESSAGEMAP_LIMIT];
Message MessageTable[] = 
{
	{ MSG_PRIVATE, MP_Privmsg, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PRIVATE },
	{ MSG_WHO, MP_Who, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_WHO },
	{ MSG_WHOIS, MP_Whois, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_WHOIS },
	{ MSG_WHOWAS, MP_Whowas, MSGPARAM_INFINITE, MSGFLAG_DELAY | MSGFLAG_COMMANDNOTSUPPORTED, TOK_WHOWAS },
	{ MSG_USER, MP_User, MSGPARAM_INFINITE, MSGFLAG_DELAY | MSGFLAG_REGISTERCOMMAND, TOK_USER },
	{ MSG_NICK, MP_Nick, MSGPARAM_INFINITE, MSGFLAG_DELAY | MSGFLAG_REGISTERCOMMAND, TOK_NICK },
	{ MSG_LIST, MP_List, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_LIST },
	{ MSG_LISTX, MP_Listx, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_LISTX },
	{ MSG_TOPIC, MP_Topic, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_TOPIC },
	{ MSG_INVITE, MP_Invite, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_INVITE },
	{ MSG_VERSION, MP_Version, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_VERSION },
	{ MSG_QUIT, MP_Quit, MSGPARAM_INFINITE, MSGFLAG_REGISTERCOMMAND, TOK_QUIT },
	{ MSG_KILL, MP_Kill, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_KILL },
	{ MSG_INFO, MP_Info, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_INFO },
	{ MSG_LINKS, MP_Links, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_LINKS },
	{ MSG_STATS, MP_Stats, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_STATS },
	{ MSG_USERS, MP_Users, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_USERS },
	{ MSG_AWAY, MP_Away, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_AWAY },
	{ MSG_PING, MP_Ping, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PING},
	{ MSG_PONG, MP_Pong, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PONG },
	{ MSG_OPER, MP_Oper, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_OPER },
	{ MSG_PASS, MP_Pass, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PASS },
	{ MSG_TIME, MP_Time, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_TIME },
	{ MSG_NAMES, MP_Names, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_NAMES },
	{ MSG_ADMIN, MP_Admin, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_ADMIN },
	{ MSG_NOTICE, MP_Notice, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_NOTICE },
	{ MSG_JOIN, MP_Join, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_JOIN },
	{ MSG_CREATE, MP_Create, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_CREATE },
	{ MSG_ACCESS, MP_Access, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_ACCESS },
	{ MSG_PROP, MP_Prop, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PROP },
	{ MSG_PART, MP_Part, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_PART },
	{ MSG_LUSERS, MP_Lusers, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_LUSERS },
	{ MSG_WHISPER, MP_Whisper, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_WHISPER },
	{ MSG_IRCX, MP_Ircx, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_IRCX },
	{ MSG_ISIRCX, MP_IsIrcx, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_ISIRCX },
	{ MSG_MOTD, MP_MOTD, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_MOTD },
	{ MSG_MODE, MP_Mode, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_MODE },
	{ MSG_KICK, MP_Kick, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_KICK },
	{ MSG_USERHOST, MP_Userhost, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_USERHOST },
	{ MSG_ISON, MP_Ison, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_ISON },
	{ MSG_SILENCE, MP_Silence, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_SILENCE },
	{ MSG_TRACE, MP_Trace, MSGPARAM_INFINITE, MSGFLAG_DELAY | MSGFLAG_COMMANDNOTSUPPORTED, TOK_TRACE },
	{ MSG_EVENT, MP_Event, MSGPARAM_INFINITE, MSGFLAG_DELAY, TOK_EVENT },
	{ MSG_SERVER, MP_Server, MSGPARAM_INFINITE, MSGFLAG_SERVERCOMMAND, TOK_SERVER },
	{ MSG_SPASS, MP_SPass, MSGPARAM_INFINITE, MSGFLAG_SERVERCOMMAND | MSGFLAG_REGISTERCOMMAND, TOK_SPASS },
	{ MSG_NJOIN, MP_NJoin, MSGPARAM_INFINITE, MSGFLAG_SERVERCOMMAND, TOK_NJOIN },
	{ MSG_SERVERSYNC, MP_Serversync, 1, MSGFLAG_SERVERCOMMAND, TOK_SERVERSYNC },
	{ MSG_USERDATA, MP_Userdata, MSGPARAM_INFINITE, MSGFLAG_SERVERCOMMAND, TOK_USERDATA },

#ifdef Z_D
	{ MSG_DEBUG, MP_Debug, 1,MSGFLAG_DELAY,TOK_DEBUG },
#endif		/* Z_D */

	{ NULL, (int (*)()) 0, 0, 0, { 0, 0} }
};


void Message_Initialize()
/*
** Message_Initialize()
** This function initializes all message processing
**
** 1) It initializes the message map in order to speed up processing of server-server
** messages.
*/
{
	int count;
	int zeroid;

	/* Find last entry and fill in message map with it */
	for (zeroid = 0; MessageTable[zeroid].command; zeroid++);

	for (count = 0; count < MESSAGEMAP_LIMIT; count++)
		MessageMap[count] = &MessageTable[zeroid];

	/* Create lookup table indexed by message table tokens */
	for (count = 0; MessageTable[count].command; count++)
		MessageMap[MessageTable[count].token[0]] = &MessageTable[count];
}

int	Message_Execute()
/*
** Message_Execute()
** We have a message waiting to be executed, so we'll do it here
*/
{
	int retval, count, mmindex = -1;
	CLIENT_STRUCT *client = scs.msginfo.c_from;

	if (Client_IsUser(client))
	/* 
	** Parse the message via string comparison, usually in the form of:
	** <command> <parameters>
	** But may also be in the form:
	** :prefix <command> <parameters>
	** NOTE: Although RFC 2518 says the only valid prefix coming from a user
	** is the users nickname, exchange appears to ignore it. Therefore, so will we.
	*/
	{
		if (scs.msginfo.argv[0][0] == ':')
		/* Prefix found in message, so lets pretend it doesnt exist */
		{
			if (scs.msginfo.argc == 1)
			/* We can ignore this message */
				return 0;

			for (count = 0; count < scs.msginfo.argc; count++)
			/* Shift all parameters to the left */
				scs.msginfo.argv[count] = scs.msginfo.argv[count + 1];

			scs.msginfo.argc--;

		}

		for (count = 0; MessageTable[count].command; count++)
		{
			if (!_stricmp(scs.msginfo.argv[0],MessageTable[count].command))
			/* Found matching command */
			{
				mmindex = MessageTable[count].token[0];
				break;
			}
		}
	}
	else if (Client_IsServer(client))
	/*
	** Parse the message via the message map.
	** Server messages are in the form:
	** :prefix <command token> <parameters>
	** NOTE: Server commands MUST be sent in tokenized form! And... we trust our servers!
	** Therefore we will assume that if we are here, argv[0] is the prefix, and argv[1] is the command
	*/
	{
		CLIENT_STRUCT *c_prefix = NULL;

		char *prefix = &scs.msginfo.argv[0][1];

		if (!scs.msginfo.argv[1][1])
		/* Sent in tokenized form */
			mmindex = scs.msginfo.argv[1][0];
		else
		/* Server sent a string */
		{
			for (count = 0; MessageTable[count].command; count++)
			{
				if (!_stricmp(scs.msginfo.argv[1],MessageTable[count].command))
				/* Found matching command */
					mmindex = MessageTable[count].token[0];
			}
		}
		
		/* Process the prefix, which is either a server token or a nickname */

		if (isstrdigit(prefix))
		/* Prefix is possibly an id */
		{
			unsigned int id = atoi(prefix);

			c_prefix = scs.CSServers[id];

			if (id >= 0 && id < MAX_SERVERTOKENS &&
				c_prefix)
			/* The token is valid */
			{
				scs.msginfo.c_from = c_prefix;
			}
			else
			/* Invalid id, silently drop(per RFC 2813). */
				return 0;
		}
		else
		{
			if (!strcmpi(prefix,client->server->name))
			/* A prefix of the server name MAY be sent ONLY by that server! */
			{
				scs.msginfo.c_prefixfrom = client;
			}
			else
			{
				char nickname[256];

				/* Use the nickname only for the prefix lookup */
				gettok(nickname,prefix,1,33);

				c_prefix = User_Find(nickname);

				if (!c_prefix)
				/* Invalid prefix, silently drop(per RFC 2813) */
					return 0;
				else
					scs.msginfo.c_prefixfrom = c_prefix;
			}
		}

		for (count = 0; count < scs.msginfo.argc; count++)
		/* Shift all parameters to the left */
			scs.msginfo.argv[count] = scs.msginfo.argv[count + 1];

		scs.msginfo.argc--;
	}

	if (mmindex == -1)
	/* Command not found, but give em a penalty anyways! */
	{
		Client_SendNumericToOne(client,ERR_UNKNOWNCOMMAND,scs.msginfo.argv[0]);
		client->parsemsg += SettingsInfo.isUser.msgdelay;
	}
	else
	/* Command found, check to see if it can be used */
	{
		if ((!(MessageMap[mmindex]->flag & MSGFLAG_REGISTERCOMMAND)) &&
			client->state == CLIENT_STATE_REGISTERING &&
			!Client_IsServer(client))
		/* Not a registration-related command, and client is not yet registered */
			Client_SendNumericToOne(client,ERR_NOTREGISTERED,NULL);
		else if ((MessageMap[mmindex]->flag & MSGFLAG_SERVERCOMMAND) &&
			(!(MessageMap[mmindex]->flag & MSGFLAG_REGISTERCOMMAND )) &&
			!Client_IsServer(client))
			Client_SendNumericToOne(client,ERR_UNKNOWNCOMMAND,scs.msginfo.argv[0]);
		else
		/* Call function to process message(MP_Privmsg, etc...) */
		{
			retval = (MessageMap[mmindex]->function());

			if (MessageMap[mmindex]->flag & MSGFLAG_DELAY)
			/* Add penalty for messages */
				client->parsemsg += SettingsInfo.isUser.msgdelay;

			return retval;
		}
	}

	return 0;
}


int MP_Privmsg()
/*
** MP_Privmsg()
** This is called whenever a user messages a destination
** NOTE: We may also get here via MP_Notice(), so we gotta watch for that!
*/
{

	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_prefixfrom;
	char tok_touse[2], msg_touse[32];

	/* Quick check if its a notice or privmsg */
	if (mi->argv[0][0] == 'n' || mi->argv[0][0] == 'N')
	/* Notice */
	{
		strcpy(tok_touse,TOK_NOTICE);
		strcpy(msg_touse,MSG_NOTICE);
	}
	else
	/* Privmsg */
	{
		strcpy(tok_touse,TOK_PRIVATE);
		strcpy(msg_touse,MSG_PRIVATE);
	}

	if (mi->argc == 1)
	/* No recipient given */
		Client_SendNumericToOne(client,ERR_NORECIPIENT,mi->argv[0]);
	else if (mi->argc == 2)
	/* No text to send */
		Client_SendNumericToOne(client,ERR_NOTEXTTOSEND,mi->argv[0]);
	else
	/* Send message to recipient */
	{
		char *target = mi->argv[1];
		CLIENT_STRUCT *ctarget = User_Find(target);

		if (ctarget)
		/* Is the target a nickname? */
		{
			/* Find out if this person is on our server */
			if (Client_IsLocal(ctarget))
			/* Send it to the person directly connected */
				Client_SendToOne(ctarget,FALSE,":%s!~%s@%s %s %s :%s",client->user->nickname,client->user->username,client->hostname,msg_touse,ctarget->user->nickname,mi->argv[2]);
			else
			/* Forward it to the next server */
				Client_SendToOne(ctarget->servernext,FALSE, ":%s!~%s@%s %s %s :%s",client->user->nickname,client->user->username,client->hostname,tok_touse,ctarget->user->nickname,mi->argv[2]);
		}
		else
		/* Nickname wasn't found, try for a channel */
		{
			CHANNEL_STRUCT *chChannel = Channel_Find(target);

			if (chChannel)
			/* Destination is a channel */
			{
				DWORD dwPriveledge = 0;

				if (!Client_IsOnChannel(client,chChannel,&dwPriveledge))
				/* User is outside of channel */
				{
					if (Channel_NoExtern(chChannel) || Channel_Moderated(chChannel))
					/* Cant send message due to +m or +n mode */
						Client_SendNumericToOne(client,ERR_CANNOTSENDTOCHAN,target);
				}
				else
				/* User should be able to message the channel, unless... */
				{
					if (Channel_Moderated(chChannel) &&
						(dwPriveledge & CHANNEL_PRIVELEDGE_NONE))
					/* Can't send message due to +m mode */
					{
						Client_SendNumericToOne(client,ERR_CANNOTSENDTOCHAN,target);
					}
					else
					/* Just message the thing already! */
					/* TODO: Check for auditorium mode */
					{
						Channel_BroadcastToLocal(chChannel,client,client,"%s %s :%s",msg_touse,chChannel->szName,mi->argv[2]);
						Server_BroadcastFromUser(client,"%s %s :%s",tok_touse,chChannel->szName,mi->argv[2]);
					}
				}
			}
			else
			/* No such nick/channel */
				Client_SendNumericToOne(client,ERR_NOSUCHNICK,target);
		}
	}

	return 0;
}
int MP_Who() { return 0; }
int MP_Whois()
/*
** MP_Whois()
** Called whenever a user requests information on another user
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;	
	CLIENT_STRUCT *c_target = NULL, *client = mi->c_from;
	char *nickname = mi->argv[1];
	char linebuf[512], sendbuf[4096];

	sendbuf[0] = 0;

    if (mi->argc < 2)
	/* Not enough parameters */
		Client_SendNumericToOne(mi->c_from,ERR_NONICKNAMEGIVEN,NULL);
	else
	/* TODO: Make accept wildcards & commas */
	{
		if (c_target = User_Find(nickname))
		/* Found 'em! */
		{
			char chbuf[1024];

			/*
			** Only display /whois information if one of the following conditions are met:
			** 1) Requesting user has at least 1 common channel with target user
			** 2) Requesting user is an admin or sysop
			** 3) Target party does not have usermode +i (invisible) set
			*/

			if ((!Client_Invisible(c_target)) || Client_IsPriveledged(client) || User_GetCommonChannels(client,c_target,NULL,NULL))
			{
				/* Donkey is ~ewtert 63.129.150.15 * [486] Advanced */
				sprintf(linebuf,":%s %d %s %s ~%s %s * :%s" CRLF,
					scs.sclient->server->name,
					RPL_WHOISUSER,
					mi->c_from->user->nickname,
					c_target->user->nickname,
					c_target->user->username,
					c_target->hostmask,
					c_target->user->fullname);
				strcat(sendbuf,linebuf);

				/* Donkey is on +#30s1 .#Cmp3 .#root @#TopPops */
				if (Client_GetWhoisChannels(mi->c_from,c_target,chbuf) != -1)
				{
					sprintf(linebuf,":%s %d %s %s :%s" CRLF,
						scs.sclient->server->name,
						RPL_WHOISCHANNELS,
						mi->c_from->user->nickname,
						c_target->user->nickname,
						chbuf);
					strcat(sendbuf,linebuf);
				}

				/* Donkey is on RockIRCX-1 RockIRCX Server #1 */
				sprintf(linebuf,":%s %d %s %s %s :%s" CRLF,
					scs.sclient->server->name,
					RPL_WHOISSERVER,
					mi->c_from->user->nickname,
					c_target->user->nickname,
					c_target->servername,
					Server_Description(User_GetServer(c_target)));
				strcat(sendbuf,linebuf);

				/* Donkey is an IRC Administrator */
				if (Client_IsAdmin(c_target) || Client_IsSysop(c_target))
				{
					sprintf(linebuf,":%s %d %s %s :is an IRC %s" CRLF,
						scs.sclient->server->name,
						RPL_WHOISSPECIAL,
						mi->c_from->user->nickname,
						c_target->user->nickname,
						Client_IsAdmin(c_target) ? "Administrator" : "Operator");
					strcat(sendbuf,linebuf);
				}

				/* Donkey signed on Sun Nov 06 11:58:10 2005 and has been idle for 5secs */
				if (Client_IsLocal(c_target))
				{
					sprintf(linebuf,":%s %d %s %s %d %u :seconds idle, signon time" CRLF,
						scs.sclient->server->name,
						RPL_WHOISIDLE,
						mi->c_from->user->nickname,
						c_target->user->nickname,
						Client_GetIdle(c_target),
						c_target->signon);
					strcat(sendbuf,linebuf);
				}

				/* Donkey from IP 127.0.0.1 */
				if (Client_IsAdmin(mi->c_from) || Client_IsSysop(mi->c_from))
				{
					sprintf(linebuf,":%s %d %s %s :from IP %s" CRLF,
						scs.sclient->server->name,
						RPL_WHOISSPECIAL,
						mi->c_from->user->nickname,
						c_target->user->nickname,
						IPFromLong(c_target->ip));
					strcat(sendbuf,linebuf);
				}
			}
		}
		else
		/* User not found */
		{
			sprintf(linebuf, ":%s %3.3d %s %s :No such nick/channel" CRLF,scs.sclient->server->name,ERR_NOSUCHNICK,mi->c_from->user->nickname,nickname);
			strcat(sendbuf,linebuf);
		}

		/* End of /Whois for Donkey */
		sprintf(linebuf,":%s %d %s %s :End of /WHOIS list" CRLF,
			scs.sclient->server->name,
			RPL_ENDOFWHOIS,
			mi->c_from->user->nickname,
			nickname);

		strcat(sendbuf,linebuf);
		Client_SendToOne(mi->c_from,FALSE,sendbuf);
	}
	return 0;
}
int MP_Whowas() { return 0; }
int MP_User()
/*
** MP_User()
** Called during initial user registration, sets the user's ident & fullname
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	if (mi->argc < 5)
		Client_SendNumericToOne(mi->c_from,ERR_NEEDMOREPARAMS,mi->argv[0]);
	else
	{
		CLIENT_STRUCT *client = mi->c_prefixfrom;

		if (!Client_Registered(client))
		/* Client not registered */
		{
			strcpy(client->user->username,mi->argv[1]);
			strcpy(client->user->fullname,mi->argv[4]);

			Valid_Username(client->user->username,TRUE);

			if (client->user->nickname[0])
			/* User is ready for welcome message */
			{
				client->user->hashkey = Hash_Add(&HT_User,client->user->nickname,client);
				LL_Add(&scs.llUserHead[client->hops],client);

				client->state = CLIENT_STATE_WELCOMING;

				Client_SendWelcome(client);
				Client_SendLusers(client);
				Client_SendMOTD(client);
				client->state = CLIENT_STATE_NORMAL;
				client->flags |= CLIENT_FLAG_REGISTERED;

				/* Let our other servers know of our guest */
				Server_Broadcast(NULL,":%d " TOK_USERDATA " %s %d %s %s %d %s :%s",
					scs.sclient->server->id,
					client->user->nickname,
					client->hops,
					client->user->username,
					client->hostname,
					scs.sclient->server->id,
					"temp",
					client->user->fullname);

				return STOP_PARSING;
			}
		}
		else
		/* Client already registered */
			Client_SendNumericToOne(client,ERR_ALREADYREGISTRED,NULL);
	}
	return 0;
}

int MP_Nick()
/*
** MP_Nick()
** Called whenever the "NICK" command is used by a local client
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	if (mi->argc < 2)
		Client_SendNumericToOne(mi->c_from,ERR_NEEDMOREPARAMS,mi->argv[0]);
	else
	{
		CLIENT_STRUCT *client = mi->c_prefixfrom;
		CLIENT_STRUCT *target = NULL;

		if (!Valid_Nickname(mi->argv[1]))
		/* Nickname specified is invalid */
			Client_SendNumericToOne(mi->c_from,ERR_ERRONEUSNICKNAME,mi->argv[1]);
		else if ((target = User_Find(mi->argv[1])) && target != client)
		/* Nickname is already in use */
			Client_SendNumericToOne(mi->c_from,ERR_NICKNAMEINUSE,mi->argv[1]);
		else if (!Client_Registered(client))
		/* Client isn't registered, so just copy over a new nickname */
		{
			Hash_Delete(&HT_User,client->user->nickname,client);

			strcpy(client->user->nickname,mi->argv[1]);

			if (client->user->username[0])
			/* Client is ready for welcoming state */
			{
				client->user->hashkey = Hash_Add(&HT_User,client->user->nickname,client);
				LL_Add(&scs.llUserHead[client->hops],client);

				client->state = CLIENT_STATE_WELCOMING;

				Client_SendWelcome(client);
				Client_SendLusers(client);
				Client_SendMOTD(client);
				client->state = CLIENT_STATE_NORMAL;
				client->flags |= CLIENT_FLAG_REGISTERED;

				/* Let our other servers know of our guest */
				Server_Broadcast(NULL,":%d " TOK_USERDATA " %s %d %s %s %d %s :%s",
					scs.sclient->server->id,
					client->user->nickname,
					client->hops,
					client->user->username,
					client->hostname,
					scs.sclient->server->id /* temp */,
					"temp",
					client->user->fullname);

				return STOP_PARSING;
			}
		}
		else if (strcmp(client->user->nickname,mi->argv[1]) != 0)
		/* Registered client requesting a nickname change, however the nickname must be different else silently ignore the request */
		{
			char szOldNick[256];

			/* Broadcast to user first */
			Client_SendToOne(client,FALSE,":%s!~%s@%s NICK %s",client->user->nickname,client->user->username,client->hostname,mi->argv[1]);

			/* Broadcast to channels */
			User_BroadcastToAllLocalsInAllChannels(client,client,"NICK :%s",mi->argv[1]);

			Hash_Delete(&HT_User,client->user->nickname,client);
			strcpy(client->user->nickname,mi->argv[1]);
			client->user->hashkey = Hash_Add(&HT_User,client->user->nickname,client);


			/* TODO: Broadcast to servers */

			/* TODO: EVENT notification */
		}
	}
	return 0;
}
int MP_List()
/*
** MP_List()
** LIST returns a list of all channels within the specified parameters
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	/* Check parameters */
	Client_SendList(mi->c_from,FALSE,mi->argv[1]);

	return 0; 
}
int MP_Listx()
/*
** MP_ListX()
** LISTX returns a list of all channels within the specified parameters (IRCX-specific command)
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	char szListXString[2048];
	int nCount;

	/* Initialize the string */
	szListXString[0] = 0;

	/* Add all parameters to list */
	for (nCount = 1; nCount < mi->argc; nCount++)
	{
		strcat(szListXString,mi->argv[nCount]);
		if (nCount != mi->argc+1)
			strcat(szListXString," ");
	}

	Client_SendList(mi->c_from,TRUE,szListXString);

	return 0;
}
int MP_Topic()
/*
** MP_Topic
** Allows the user to change the topic of a channel. Only ops can set topic if +t is set.
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CHANNEL_STRUCT *chTarget = NULL;
	CLIENT_STRUCT *client = mi->c_prefixfrom;
	DWORD dwUserModeFlags = 0;

	if (mi->argc < 2)
	/* Not enough parameters */
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}

	chTarget = Channel_Find(mi->argv[1]);

	if (chTarget == NULL)
	/* Channel not found */
	{
		Client_SendNumericToOne(client,ERR_NOSUCHCHANNEL,mi->argv[1]);
		return 0;
	}

	if (mi->argc == 2)
	/* Display topic */
	{
		if (!Client_IsOnChannel(client,chTarget,NULL))
		/* Do not display topic to outsider */
			Client_SendNumericToOne(client,ERR_CHANOPRIVSNEEDED,mi->argv[1]);
		else
			Client_SendToOne(client,FALSE,":%s %3.3d %s %s :%s",SettingsInfo.isGeneral.servername,332,Client_Nickname(client),mi->argv[1],chTarget->szPropTopic);

		return 0;
	}

	/* Check if channel mode is +t and ops status */
	if ((chTarget->dwModes & CHANNELMODE_TOPICOP) && 
		(!(Channel_GetUserModeFlags(chTarget,client) & CHANNEL_PRIVELEDGE_OWNER) &&
		!(Channel_GetUserModeFlags(chTarget,client) & CHANNEL_PRIVELEDGE_HOST)))
	/* Cannot set topic */
	{
		Client_SendNumericToOne(client,ERR_CHANOPRIVSNEEDED,mi->argv[1]);
	}
	else
	/* Set channel topic */
	{
		/* Prevent buffer overflow attack */
		if (strlen(mi->argv[2]) > 256)
			mi->argv[256] = 0;
			
		strcpy(chTarget->szPropTopic,mi->argv[2]);

		Channel_BroadcastToLocal(chTarget,mi->c_prefixfrom,NULL,MSG_TOPIC " %s :%s",chTarget->szName,mi->argv[2]);
		Server_BroadcastFromUser(mi->c_prefixfrom,MSG_TOPIC " %s :%s",chTarget->szName,mi->argv[2]);
	}

	return 0;
}
int MP_Invite() { return 0; }
int MP_Version()
/*
** MP_Version()
** Called whenever a client issues the "VERSION" command
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	Client_SendNumericToOne(mi->c_from,RPL_VERSION,"Written by Zeb Rasco");

	return 0; 
}
int MP_Quit()
/*
** MP_Quit()
** Called whenever a client issues the "QUIT" command
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	/* Mark this user as dead, and record his quit message */
	mi->c_prefixfrom->state = CLIENT_STATE_DEAD;

	if (mi->argc > 1)
	/* Display quit message */
	{
		mi->c_prefixfrom->quitmessage = (char*)calloc(1,strlen(mi->argv[1]) + 1);
		strcpy(mi->c_prefixfrom->quitmessage,mi->argv[1]);
	}
	else
	/* Quit message = nickname if blank */
	{
		mi->c_prefixfrom->quitmessage = (char*)calloc(1,strlen(mi->c_prefixfrom->user->nickname) + 1);
		strcpy(mi->c_prefixfrom->quitmessage,mi->c_prefixfrom->user->nickname);
	}


	if (Client_IsUser(mi->c_from))
	{
		LINKED_LIST_STRUCT *llChannelHead = (LINKED_LIST_STRUCT*)(&mi->c_prefixfrom->user->llChannelHead);
		CHANNEL_STRUCT *chChannel = NULL;

		while (llChannelHead->next)
		/* Remove user from channel(s) and broadcast quit message */
		{
			llChannelHead = llChannelHead->next;

			if (llChannelHead != NULL)
			{
				chChannel = (CHANNEL_STRUCT*)llChannelHead->data;

				Channel_BroadcastToLocal(chChannel,mi->c_prefixfrom,mi->c_prefixfrom,MSG_QUIT " :%s",mi->c_prefixfrom->quitmessage);
				Server_BroadcastFromUser(mi->c_prefixfrom,MSG_QUIT " :%s",mi->c_prefixfrom->quitmessage);
			}
		}

		//Channel_BroadcastToLocal(chChannel,client,client,"%s %s :%s",msg_touse,chChannel->szName,mi->argv[2]);
		//Server_BroadcastFromUser(client,"%s %s :%s",tok_touse,chChannel->szName,mi->argv[2]);
		return STOP_PARSING; 
	}
	else
		return 0;
}
int MP_Kill() { return 0; }
int MP_Info()
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	if (mi->argc > 1)
	/* Too many parameters (Error: Server option for this command not supported */
		Client_SendToOne(mi->c_from,FALSE,":%s %3.3d %s %s :Server option for this command is not supported.",SettingsInfo.isGeneral.servername,555,Client_Nickname(mi->c_from),mi->argv[1]);
	else
	/* Show info */
	{
		Client_SendToOne(mi->c_from,FALSE,":%s %3.3d %s :RockIRCX IRC server. Copyright 2008 Zeb Rasco.",SettingsInfo.isGeneral.servername,371,Client_Nickname(mi->c_from));
		Client_SendToOne(mi->c_from,FALSE,":%s %3.3d %s :End of /INFO list",SettingsInfo.isGeneral.servername,374,Client_Nickname(mi->c_from));
	}
	return 0;
}
int MP_Links() { return 0; }
int MP_Stats() { return 0; }
int MP_Users() { return 0; }
int MP_Away() { return 0; }
int MP_Ping() { return 0; }
int MP_Pong() { return 0; }
int MP_Oper() { return 0; }
int MP_Pass() { return 0; }
int MP_Time() { return 0; }
int MP_Names()
/*
** MP_Names()
** Called whenever a user requests a /NAMES list for a channel
*/
{
	/* TODO: Add support for wildcards & commas */
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from;
	CHANNEL_STRUCT *chTarget;

	if (chTarget = Channel_Find(mi->argv[1]))
	/* Channel found */
		Channel_SendNames(chTarget,client);
	else
		Client_SendNumericToOne(client,RPL_ENDOFNAMES,mi->argv[1]);

	return 0;
}
int MP_Admin() { return 0; }
int MP_Notice()
/*
** MP_Notice()
** Called whenever a user issues a NOTICE command
** We'll use a sneaky trick here, and just call MP_Privmsg with argv[0] being NOTICE ;)
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	if (Client_IsServer(mi->c_from) &&
		mi->argc >= 3 &&
		mi->c_from->server->connected == SERVER_OUTBOUND &&
		strcmp(mi->argv[0],"NOTICE") == 0 &&
		strcmp(mi->argv[1],"AUTH") == 0)
	/* Silently drop our introductory NOTICE AUTH messages */
		return 0;
	else
        return MP_Privmsg();
}

int MP_Join()
/*
** MP_Join()
** Called whenever a user attempts to join a channel
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_prefixfrom;
	CHANNEL_STRUCT *chTarget;
	LINKED_LIST_STRUCT llChannelHead, *llChannelPtr = &llChannelHead;
	int tokcount = 0;
	char currchannel[512];

	if (mi->argc < 2)
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}

	/* Create our list of channels */
	Parse_ChannelList(mi->argv[1],&llChannelHead);

	while (llChannelPtr->next)
	/* Go thru our list of channels passed */
	{
		tokcount++;
		llChannelPtr = llChannelPtr->next;

		chTarget = (CHANNEL_STRUCT*)(llChannelPtr->data);
		gettok(currchannel,mi->argv[1],tokcount,',');

		if (chTarget == NULL)
		/* TEMP: NO CHECKING! Channel not found, create a new one */
		{
			CHANNEL_STRUCT *chNew = NULL;

			if (!Valid_Channelname(currchannel))
			/* Channelname is not valid */
				Client_SendNumericToOne(client,ERR_NOSUCHCHANNEL,currchannel);
			else
			/* Create new channel after checking if the name is valid */
			{
				chNew = Channel_CreateDefault(currchannel);

				/* TEMP: Add him as owner! */
				Channel_AddUser(chNew,client,CHANNEL_PRIVELEDGE_OWNER);
			}
		}
		else
		/* Channel found, NO CHECKING!! */
		{
			Channel_AddUser(chTarget,client,CHANNEL_PRIVELEDGE_NONE);
		}
	}

	LL_Clear(&llChannelHead);

	return 0;
}

int MP_Create() { return 0; }
int MP_Access() { return 0; }
int MP_Prop() { return 0; }
int MP_Part()
/*
** MP_Part()
** This function is called whenever a user parts a channel
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_prefixfrom;
	CHANNEL_STRUCT *chTarget = NULL;
	LINKED_LIST_STRUCT llChannelHead, *llChannelPtr = &llChannelHead;
	int tokcount = 0;
	char currchannel[512];

	if (mi->argc < 2)
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}

	/* Create our list of channels */
	Parse_ChannelList(mi->argv[1],&llChannelHead);

	while (llChannelPtr->next)
	/* Go thru our list of channels passed */
	{
		tokcount++;
		llChannelPtr = llChannelPtr->next;

		chTarget = (CHANNEL_STRUCT*)(llChannelPtr->data);
		gettok(currchannel,mi->argv[1],tokcount,',');

		if (chTarget == NULL)
		/* Channel doesn't exist */
			Client_SendNumericToOne(client,ERR_NOSUCHCHANNEL,currchannel);
		else
		/* Channel found, let's see if they're on it */
		{
			if (Client_IsOnChannel(client,chTarget,NULL))
			/* Let's get them outta there! */
			{
				Channel_BroadcastToLocal(chTarget,client,NULL,MSG_PART " %s",chTarget->szName);
				Server_BroadcastFromUser(client,MSG_PART " %s",chTarget->szName);
				Channel_DeleteUser(chTarget,client);

				if (chTarget->dwUsers < 1)
					Channel_Cleanup(chTarget);
			}
			else
			/* They aren't on that channel */
				Client_SendNumericToOne(client,ERR_NOTONCHANNEL,currchannel);
		}
	}

	LL_Clear(&llChannelHead);

	return 0;
}

int MP_Lusers()
/*
** MP_Lusers()
** Called whenever a lusers request is issued by a client
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	Client_SendLusers(mi->c_from);

	return 0; 
}
int MP_Whisper() { return 0; }
int MP_Ircx()
/*
** MP_Ircx()
** Used by clients to enter IRCX mode
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	mi->c_from->user->bInIRCX = TRUE;

	MP_IsIrcx();

	return 0;
}
int MP_IsIrcx()
/*
** MP_IsIrcx()
** Used by clients to determine if the server supports IRCX
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;

	Client_SendNumericToOne(mi->c_from,IRCRPL_IRCX,NULL);

	return 0;
}
int MP_MOTD() { return 0; }
int MP_Mode()
/*
** MP_Mode()
** Called whenever a user issues the MODE command
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from, *csTarget = NULL;
	CHANNEL_STRUCT *chTarget;

	if (mi->argc < 2)
	/* Not enough parameters */
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}
	if (csTarget = User_Find(mi->argv[1]))
	/* User exists */
	{
		if ((Client_Invisible(csTarget) && !Client_IsPriveledged(client)) && csTarget != client)
		/* If requesting client is a non-oper, and the target user is invisible, pretend user doesn't exist */
			Client_SendNumericToOne(client,ERR_NOSUCHCHANNEL,mi->argv[1]);
		else if ((csTarget != client) && (!Client_IsPriveledged(client)))
		/* User exists and is another user, and requesting client is not priviledged */
			Client_SendNumericToOne(client,ERR_USERSDONTMATCH,NULL);
		else
		/* User is changing/displaying modes for themselves or someone else */
		{
			int nIndex = 0;
			BOOL bMinus = FALSE;
			char ch;
			char szDisplayStr[256];
			BOOL bWasPriveledged = Client_IsPriveledged(client);
			BOOL bWasInvisible = Client_Invisible(client);

			/* 0 = leave mode as-is */
			/* 1 = grant mode */
			/* 2 = take mode away */
			int nTransform[256];

			/* Clear transformation matrix */
			memset(&nTransform,0,sizeof(nTransform));
			szDisplayStr[0] = 0;

			if (bWasPriveledged == FALSE && client != csTarget)
			/* Normal users cannot change/view modes of other users */
			{
				Client_SendNumericToOne(client,ERR_USERSDONTMATCH,NULL);
				return 0;
			}

			if (mi->argc == 2)
			/* User is displaying modes */
			{
				User_GetModeString(csTarget,szDisplayStr,(!Client_IsPriveledged(client)));
				Client_SendToOne(client,FALSE,":%s %3.3d %s +%s",SettingsInfo.isGeneral.servername,RPL_UMODEIS,Client_Nickname(csTarget),szDisplayStr);
				return 0;
			}

			while (mi->argv[2][nIndex])
			/* Go through each mode */
			{
				ch = mi->argv[2][nIndex];

				if (ch == '-')
					bMinus = TRUE;
				else if (ch == '+')
					bMinus = FALSE;
				else if (ch == 'i' || ch == 'o' || ch == 'a' || ch == 'z')
				/* Plus modes will override minus modes */
				{
					if (ch != 'z' && client != csTarget)
						Client_SendNumericToOne(client,ERR_USERSDONTMATCH,NULL);
					else
					{
						if (ch == 'z' && ((Client_IsPriveledged(csTarget)) || client == csTarget ))
						/* Cannot set +z for opers/admins, or for yourself */
							Client_SendNumericToOne(client,ERR_USERSDONTMATCH,NULL);
						else
							if (bMinus == FALSE)
								nTransform[ch] = 1;
							else if (nTransform[ch] != 1)
								nTransform[ch] = 2;
					}
				}
				else
					Client_SendNumericToOne(client,ERR_UMODEUNKNOWNFLAG,NULL);

				nIndex++;
			}

			/* Go through transformation matrix and apply/display changes. Plus modes displayed first and then minus modes */

			/* Add + if any modes are to be added */
			if (nTransform['a'] == 1 || nTransform['i'] == 1 || nTransform['o'] == 1 || nTransform['z'] == 1)
			{
				nIndex = 1;

				szDisplayStr[0] = '+';

				if (nTransform['a'] == 1)
				{
					csTarget->modeflag |= CLIENT_MODE_ADMIN;
					szDisplayStr[nIndex++] = 'a';
				}
				if (nTransform['i'] == 1)
				{
					csTarget->modeflag |= CLIENT_MODE_INVISIBLE;
					szDisplayStr[nIndex++] = 'i';
				}
				if (nTransform['o'] == 1)
				{
					csTarget->modeflag |= CLIENT_MODE_SYSOP;
					szDisplayStr[nIndex++] = 'o';
				}
				if (nTransform['z'] == 1)
				{
					csTarget->modeflag |= CLIENT_MODE_GAG;
					szDisplayStr[nIndex++] = 'z';
				}

				/* Add to operator count in lusers (if applicible) */
				if ((nTransform['a'] == 1 || nTransform['o'] == 1) && Client_IsPriveledged(client) && bWasPriveledged == FALSE)
					scs.lusers.nOpsOnline++;

				/* Add to invisible users count in lusers (if applicible) */
				if (nTransform['i'] == 1 && bWasInvisible == FALSE)
					scs.lusers.nInvisible++;

				szDisplayStr[nIndex] = 0;
			}
			/* Add - if any modes are to be taken away */
			if (nTransform['a'] == 2 || nTransform['i'] == 2 || nTransform['o'] == 2 || nTransform['z'] == 2)
			{
				int len = strlen(szDisplayStr);

				nIndex = len;

				szDisplayStr[nIndex++] = '-';
				szDisplayStr[nIndex] = 0;

				if (nTransform['a'] == 2)
				{
					csTarget->modeflag &= ~CLIENT_MODE_ADMIN;
					szDisplayStr[nIndex++] = 'a';
				}
				if (nTransform['i'] == 2)
				{
					csTarget->modeflag &= ~CLIENT_MODE_INVISIBLE;
					szDisplayStr[nIndex++] = 'i';
				}
				if (nTransform['o'] == 2)
				{
					csTarget->modeflag &= ~CLIENT_MODE_SYSOP;
					szDisplayStr[nIndex++] = 'o';
				}
				if (nTransform['z'] == 2)
				{
					csTarget->modeflag &= ~CLIENT_MODE_GAG;
					szDisplayStr[nIndex++] = 'z';
				}

				/* Subtract from operator count in lusers (if applicible) */
				if ((nTransform['a'] == 2 || nTransform['o'] == 2) && (!Client_IsPriveledged(client)) && bWasPriveledged == TRUE)
					scs.lusers.nOpsOnline--;

				/* Subtract from invisible count in lusers (if applicible) */
				if (nTransform['i'] == 2 && bWasInvisible == TRUE)
					scs.lusers.nInvisible--;

				szDisplayStr[nIndex] = 0;
			}

			/* Display the mode changes */
			if (strlen(szDisplayStr) > 0)
				Client_SendToOne(client,FALSE,":%s MODE %s :%s",Client_Nickname(csTarget),Client_Nickname(csTarget),szDisplayStr);
		}
	}
	else
	/* No user, try to find a channel */
	{
		if (chTarget = Channel_Find(mi->argv[1]))
		/* Channel exists */
		{
			if (mi->argc < 3)
			/* Person is trying to display modes for channel */
			{
				char modebuf[256];
				char sendbuf[512];

				Channel_GetModeString(chTarget,modebuf);
				
				strcpy(sendbuf,chTarget->szName);
				strcat(sendbuf," ");
				strcat(sendbuf,modebuf);

				/* Display channel modes */
				Client_SendNumericToOne(client,RPL_CHANNELMODEIS,sendbuf);
			}
			else
			/* Person is either trying to change modes or get more detailed information */
			{
			}
		}
		else
		/* Target does not exist */
			Client_SendNumericToOne(client,ERR_NOSUCHCHANNEL,mi->argv[1]);
	}

	return 0;
}
int MP_Kick() { return 0; }
int MP_Userhost() { return 0; }
int MP_Ison() { return 0; }
int MP_Silence() { return 0; }
int MP_Trace() { return 0; }
int MP_Event() { return 0; }

int	MP_Server()
/*
** MP_Server()
** Command sent between servers only, used to register a new server on the network
** Format: SERVER <servername> <hopcount> <id#> <description>
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *c_server = mi->c_from, *c_new = NULL;
	int hopcount = atoi(mi->argv[2]), id = atoi(mi->argv[3]);

	/* Update the hop count */
	hopcount++;

	if (hopcount > 1)
	/* Create new structure to house server information */
	{
		c_new = (CLIENT_STRUCT*)calloc(1,sizeof(CLIENT_STRUCT));
		c_new->server = (SERVER_STRUCT*)calloc(1,sizeof(SERVER_STRUCT));

		c_new->server->connected = SERVER_REMOTE;
	}
	else
	/* We already have this server allocated(c_server) */
	{
		c_new = c_server;
		scs.lusers.nLocalServers++;
	}

	c_new->server->id = id;
	strcpy(c_new->servername,c_server->server->name);
	strcpy(c_new->server->name,mi->argv[1]);
	strcpy(c_new->server->description,mi->argv[4]);
	c_new->servernext = mi->c_from;
	c_new->serverkey = Hash_MakeKey(&HT_Server,c_new->servername);
	c_new->hops = hopcount;

	scs.lusers.nGlobalServers++;

	/* Put this new server in the hash table & server linked lists */
	c_new->server->hashkey = Hash_Add(&HT_Server,c_new->server->name,c_new);
	LL_Add(&scs.llServerHead[c_new->hops],c_new);

	scs.CSServers[c_new->server->id] = c_new;

	if (hopcount <= 1)
		Serverlist_ChangeStatus(c_server->server->name,TRUE);
    
	return 0;
}
int MP_SPass()
/*
** MP_SPass()
** New RockIRCX command, used for newly connecting servers.
** Format: SPASS <password> <network name> <server name> <version>
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from;
	ServerList *curr = &SettingsInfo.isServers.serverhead;

	if (mi->argc < 5)
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}

	/* First check that network name & version are compatible */

	if (strcmp(mi->argv[2],SettingsInfo.isGeneral.networkname))
	/* Invalid network name */
	{
		Client_SendError(client,TRUE,"Closing Server Link: Network names do not match.");
		return STOP_PARSING;
	}
	else if (strcmp(mi->argv[4],ROCKIRCX_PROTOCOL_VERSION))
	/* Invalid version */
	{
		Client_SendError(client,TRUE,"Closing Server Link: Incorrect protocol version.");
		return STOP_PARSING;
	}

	while (curr->next)
	/* Attempt to find matching inbound server */
	{
		curr = curr->next;

		if (!curr->port && match(curr->hostmask,client->hostname) == 0)
		/* Found match for hostmask(inbound servers only) */
		{
			if (strcmp(curr->name,mi->argv[3]) == 0)
			/* Found the right server */
			{
				if (strcmp(curr->password,mi->argv[1]) == 0)
				/* Right server & right password */
				{
					/* Client is no longer a user, but now a server */
					free(client->user);
					client->user = NULL;
					client->flags |= CLIENT_FLAG_SERVERSYNC;

					client->server = (SERVER_STRUCT*)calloc(1,sizeof(SERVER_STRUCT));
					client->serverkey = scs.skey;
					strcpy(client->servername,scs.sclient->server->name);

					strcpy(client->server->name,mi->argv[3]);
					client->server->connected = SERVER_INBOUND;

					scs.lusers.nUnknown--;

					return STOP_PARSING;
				}
				else
				/* Right server, wrong password */
				{
					char *buf;

					/* Bulletproof this buffer overflow opprotunity */
					buf = (char*)malloc(strlen(mi->argv[3]) + strlen(mi->argv[1]) + 512 );

					Client_SendError(client,TRUE,"Closing Server Link: Invalid password(Your attempt has been logged)");
					sprintf(buf,"Failed server login attempt from %s(%s), password used: %s",mi->argv[3],client->hostname,mi->argv[1]);
					TechLog_AddEntry(buf,BITMAP_WARNING);

					free(buf);

					return STOP_PARSING;
				}
			}
		}
	}


	return 0;
}

int MP_NJoin()
/*
** MP_NJoin()
** This command is used in server-server communication only, and is used to update
** channel information.
** Usage: NJOIN <name> <timestamp> <modes> <limit> <User list>
** Example: NJOIN #Pirates 932543 +ntxl 500 :.Blackbeard .Pegleg @Scallywag +Mutany-man PoopDeck
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *c_server = mi->c_from;
	CHANNEL_STRUCT *chChannel;
	unsigned long dwRemoteCreationTime = atol(mi->argv[2]),
					dwLimit = atol(mi->argv[4]);

	/* Do we already have this channel? If so, process for channel collision */
	chChannel = Channel_Find(mi->argv[1]);

	if (chChannel)
	/*
	** Channel collision!
	** The mechanism for channel collisions is simple, a timestamp will be used.
	** If our channel is older, we need not do anything here as our subsequent NJOIN
	** message will automatically take care of things for us.
	*/
	{
		if (dwRemoteCreationTime <= chChannel->dwPropCreationTime)
		/* Their channel is older, and will take over ours. KILL our channel :( */
		{
			Channel_KickAllLocal(chChannel,"System",NULL);
			Channel_DeleteAllUsers(chChannel);
			Channel_Cleanup(chChannel);
			// Channel_Kill
			//
		}
		else if (c_server->flags & CLIENT_FLAG_CHANNELSYNC)
		/* We dont have to issue a KILL back, because our following NJOIN will do it */
			return 0;
		else
		/*
		** Rare, but can happen if two servers join the network on opposite ends
		** All we can do is keep our info and issue a KILL in the opposite direction
		*/
			Client_SendToOne(c_server,FALSE,":System " TOK_KILL " %s",chChannel->szName);
	}

	/* Make a new channel with their parameters */
	chChannel = Channel_Create(mi->argv[1]);

	chChannel->dwPropCreationTime = dwRemoteCreationTime;
	chChannel->dwLimit = dwLimit;

	/* Add our modes */
	chChannel->dwModes = Channel_GetModeFlagFromString(chChannel,mi->argv[3]);
	/* Add our users(TODO: Find a way to account for users for nickname collisions!) */
	Channel_AddUsersFromList(chChannel,mi->argv[5]);

	/* No sense in sending this one back on our subsequent NJOIN */
	chChannel->dwModes |= CHANNELMODE_COLLISIONVICTIM;

	return 0;
}

int MP_Serversync()
/*
** MP_ServerSync()
** This command is used when a server is done sending information, used to sync
** id gathering of servers. It is called after all SERVER, NICK, and NJOIN messages.
** Usage: SERVERSYNC
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from;
	char buf[256];

	if (client->flags & CLIENT_FLAG_SERVERSYNC)
	/* All server information sent */
	{

		client->flags &= ~CLIENT_FLAG_SERVERSYNC;
		client->flags |= CLIENT_FLAG_USERSYNC;

		if (client->server->connected == SERVER_INBOUND)
		/* The remote connecting server has sent all the info, now send ours */
		{
			int count, count2;
			char sub_buf[1024];
			LINKED_LIST_STRUCT *curr;
			CLIENT_STRUCT *c_info;

			Client_SendToOne(client,FALSE,":%s " TOK_SERVER " %s 0 %d :%s\r\n",scs.sclient->server->name,scs.sclient->server->name,scs.sclient->server->id,scs.sclient->server->description);

			for (count = 0; count < MAX_HOPS; count++)
			/* Send info about every server */
			{
				curr = &scs.llServerHead[count];

				while (curr->next)
				/* Get next server which is <count> hops away */
				{
					curr = curr->next;

					c_info = (CLIENT_STRUCT*)curr->data;

					if (c_info->servernext != client)
					/* Send info about all servers */
						Client_SendToOne(client,FALSE,":%d " TOK_SERVER " %s %d %d :%s\r\n",scs.sclient->server->id,c_info->server->name,c_info->hops,c_info->server->id,c_info->server->description);
				}
			}
			
			Client_SendToOne(client,FALSE,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		}
		else if (client->server->connected == SERVER_OUTBOUND)
		/* Once we recieve a SERVERSYNC from an outbound server, we know its connected */
			Serverlist_ChangeStatus(client->server->name,TRUE);
	}
	else if (client->flags & CLIENT_FLAG_USERSYNC)
	/* All user information sent */
	{
		client->flags &= ~CLIENT_FLAG_USERSYNC;
		//client->flags ^= CLIENT_FLAG_CHANNELSYNC;
		client->flags |= CLIENT_FLAG_CHANNELSYNC;

		if (client->server->connected == SERVER_INBOUND)
		{
			/* Send all user information */
			int count = 0;
			LINKED_LIST_STRUCT *curr = NULL;
			CLIENT_STRUCT *c_target, *c_server = NULL;

			for (count = 0; count < MAX_HOPS; count++)
			/* Send all user information available */
			{
				curr = &scs.llUserHead[count];

				while (curr->next)
				{
					/* Get next user */
					curr = curr->next;

					c_target = (CLIENT_STRUCT*)curr->data;
					c_server = User_GetServer(c_target);

					if (c_target->servernext != client)
					/* The target server already knows about these users!! */
					{
						Client_SendToOne(client,FALSE,":%s " TOK_USERDATA " %s %d %s %s %d %s :%s",
							c_server->server->name,
							c_target->user->nickname,
							c_target->hops,
							c_target->user->username,
							c_target->hostname,
							c_server->server->id,
							"temp",
							c_target->user->fullname);
					}
				}
			}

			Client_SendToOne(client,FALSE,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		}
	}
	else if (client->flags & CLIENT_FLAG_CHANNELSYNC)
	/* All channel information sent */
	{
		client->flags &= ~CLIENT_FLAG_CHANNELSYNC;

		if (client->server->connected == SERVER_INBOUND)
		{
			CHANNEL_STRUCT *chChannel = NULL;
			LINKED_LIST_STRUCT *llChannel = &(scs.llChannelHead);
			char szMode[64], szNameslist[32768];

			while (llChannel->next)
			/* TODO: Send all our channel information(after the NJOIN messages) */
			{
				llChannel = llChannel->next;

				chChannel = (CHANNEL_STRUCT*)(llChannel->data);

				if (chChannel->dwModes & CHANNELMODE_COLLISIONVICTIM)
				/* Don't send back channels if there was a collision */
					chChannel->dwModes &= ~CHANNELMODE_COLLISIONVICTIM;
				else
				{
					/* Get our modes and names list for our NJOIN message */
					Channel_GetModeString(chChannel,szMode);
					Channel_CreateUserlist(chChannel,szNameslist,sizeof(szNameslist));

					Client_SendToOne(client,FALSE,":%s " TOK_NJOIN " %s %d %s %d :%s" CRLF,
						scs.sclient->server->name,
						chChannel->szName,
						chChannel->dwPropCreationTime,
						szMode,
						chChannel->dwLimit,
						szNameslist);

					/* TODO: Send all PROP and ACCESS entries */
				}
			}

			Client_SendToOne(client,FALSE,":%d " TOK_SERVERSYNC "\r\n",scs.sclient->server->id);
		}

		sprintf(buf,"Synchronized link with %s established.",client->server->name);
		TechLog_AddEntry(buf,BITMAP_OK);
	}

	return 0;
}

int MP_Userdata()
/*
** MP_Userdata()
** Server-to-server command used to add a nickname to the network
** Usage: USERDATA <nick> <hops> <username> <host> <server id#> <umode> <realname>
** Example: USERDATA Donkey 1 ident phx.cox.net 1 +i :Full name goes here
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from;

	if (mi->argc > 7)
	/* This should be sufficient for error-checking */
	{
		CLIENT_STRUCT *csnew = (CLIENT_STRUCT*)calloc(1,sizeof(CLIENT_STRUCT));

		if (!csnew)
		/* Unable to calloc */
			ODS("Unable to allocate new user data! (MP_Userdata, csnew allocation)");
		else
		/* Assign new user stuff */
		{
			CLIENT_STRUCT *c_server = NULL;
			unsigned int id = atoi(mi->argv[5]);

			/* Step #1: Look up the server using the id */
			c_server = scs.CSServers[id];

			if (id >= 0 && id < MAX_SERVERTOKENS &&
				c_server)
			/* The id is valid */
			{
				CLIENT_STRUCT *c_collision = NULL;

				/* Step #2: Check for nickname collision */
				if (c_collision = User_Find(mi->argv[2]))
				/* TEMP: disconnect the client on the server */
				{
					c_collision->state = CLIENT_STATE_DEAD;

					return 0;
				}

				/* Step #2: Create the new user */
				csnew->user = (USER_STRUCT*)calloc(1,sizeof(USER_STRUCT));

				if (!csnew->user)
				/* Unable to allocate */
				{
					free(csnew);
					ODS("Unable to allocate new user(MP_Userdata, csnew->user allocation)");
				}
				else
				/* Create the new user information */
				{
					strcpy(csnew->user->nickname,mi->argv[1]);
					strcpy(csnew->user->username,mi->argv[3]);
					strcpy(csnew->user->fullname,mi->argv[7]);

					/* Update our counters */
					scs.lusers.nGlobalUsers++;

					if (scs.lusers.nGlobalUsers > scs.lusers.nGlobalMax)
						scs.lusers.nGlobalMax = scs.lusers.nGlobalUsers;

					csnew->hops = atol(mi->argv[2]);
					csnew->hops++;
					
					csnew->state = CLIENT_STATE_NORMAL;

					csnew->servernext = c_server;
					strcpy(csnew->servername,c_server->server->name);
					csnew->serverkey = c_server->server->hashkey;

					strcpy(csnew->hostname,mi->argv[4]);

					/* Mask the IP address */
					strcpy(csnew->hostmask,csnew->hostname);

					/* Add this user to the database */
					csnew->user->hashkey = Hash_Add(&HT_User,csnew->user->nickname,csnew);
					LL_Add(&scs.llUserHead[csnew->hops],csnew);

					/* Step #3: Send the information to other servers */
					Server_Broadcast(csnew->servernext,":%d " TOK_USERDATA " %s %d %s %s %d %s :%s",
						scs.sclient->server->id,
						csnew->user->nickname,
						csnew->hops,
						csnew->user->username,
						csnew->hostname,
						c_server->server->id /* temp */,
						"temp",
						csnew->user->fullname);
				}
			}
		}
	}

	return 0;
}

#ifdef Z_D
int MP_Debug()
/*
** MP_Debug()
** Enabled only if Z_D is defined!
** This command allows a client to recieve debug information, and the only valid
** password is the RA password!
** Usage: DEBUG <command> <parameters>
*/
{
	MESSAGE_CONTROL_STRUCT *mi = &scs.msginfo;
	CLIENT_STRUCT *client = mi->c_from;

	if (mi->argc < 2)
	{
		Client_SendNumericToOne(client,ERR_NEEDMOREPARAMS,mi->argv[0]);
		return 0;
	}

	if (stricmp(mi->argv[1],"LOGIN") == 0)
	{
		if (strcmp(mi->argv[2],SettingsInfo.isSecurity.RAPassword) == 0)
		{
			scs.dbgclient = client;
			Client_SendNumericToOne(client,999,"You are now the debug client");
		}
		else
		/* We dont like people messing with the debugger! */
		{
			client->state = CLIENT_STATE_DEAD;
			return STOP_PARSING;
		}
	}
	else
		if (client != scs.dbgclient)
		/* We dont like people messing with the debugger! */
		{
			client->state = CLIENT_STATE_DEAD;
			return STOP_PARSING;
		}
		else
		{
			if (stricmp(mi->argv[1],"USERS") == 0)
			/* Print list of all connected users */
			{
				int count;
				LINKED_LIST_STRUCT *curr;
				CLIENT_STRUCT *c_client;
				char buf[256];

				Client_SendNumericToOne(client,999,"***DEBUG*** Users connected to network:");

				for (count = 0; count < MAX_HOPS; count++)
				{
					curr = &scs.llUserHead[count];

					while (curr->next)
					{
						curr = curr->next;
						c_client = (CLIENT_STRUCT*)curr->data;

						sprintf(buf,"***DEBUG*** R/L Ports: %d/%d, Mask == %s!%s@%s, hops == %d",c_client->port_r,c_client->port_l,c_client->user->nickname,c_client->user->username,c_client->hostname,c_client->hops);
						Client_SendNumericToOne(client,999,buf);
					}
				}

				Client_SendNumericToOne(client,999,"***DEBUG*** End of user list:");
			}
		}

	return 0;
}
#endif		/* Z_D */