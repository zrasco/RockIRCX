/*
** strbuf.cpp
**
** This file contains all functions for the string buffering system used by 
** RockIRCX
*/

#include "strbuf.h"
#include <crtdbg.h>

void StrBuf_Empty(StrBuffer *strbuf)
/*
** StrBuf_Empty()
** This function will clear & deallocate the string buffer
*/
{
    if (strbuf->string)
		free(strbuf->string);

	strbuf->string = NULL;
	strbuf->length = 0;
}

int	StrBuf_Add(StrBuffer *strbuf, const char* string, int length)
/*
** StrBuf_Add()
** This function adds the string specified to the string buffer
** Returns: < 0 if error, else # of bytes copied
** NOTE: Make sure length does not exceed bounds of string!!!!
*/
{
	char *copyloc, *ptr;

	if (strbuf->string)
	/* Append to existing buffer */
	{
		ptr = (char*)realloc(strbuf->string,StrBuf_Length(strbuf) + length);

		if (!ptr)
		/* Unable to re-allocate */
		{
			StrBuf_Empty(strbuf);

			return -1;
		}
		else
		/* Get location of memory-copy */
		{
			strbuf->string = ptr;
			copyloc = &strbuf->string[StrBuf_Length(strbuf)];
		}
	}
	else
	/* Buffer is empty */
	{
		strbuf->string = (char*)malloc(length);
		copyloc = strbuf->string;

		if (!copyloc)
		/* Unable to allocate */
			return -1;
	}

	memcpy(copyloc,string,length);
	strbuf->length += length;

	return length;
}

int StrBuf_Delete(StrBuffer *strbuf, int mark)
/*
** StrBuf_Delete()
** This function deletes the specified string buffer up to the mark
** Returns < 0 if re-allocation failed
*/
{
    unsigned int bmark = mark;

	if (bmark > StrBuf_Length(strbuf))
		bmark = StrBuf_Length(strbuf);

	if (!bmark)
		return bmark;

	/* Move string up and re-allocate */
	if (bmark == StrBuf_Length(strbuf))
		StrBuf_Empty(strbuf);
	else
	{
		char *ptr;
		strbuf->string = &strbuf->string[mark];
		ptr = (char*)realloc(strbuf->string,StrBuf_Length(strbuf) - mark);

		if (!ptr)
		/* Re-allocation failed */
		{
			StrBuf_Empty(strbuf);
			return -1;
		}
		else
		{
            strbuf->string = ptr;
			strbuf->length -= mark;
		}
	}

	return bmark;
}

int StrBuf_Read(StrBuffer *strbuf, char *readbuffer, int length, BOOL bPeek)
/*
** StrBuf_Read()
** Reads the string buffer and fills the user's buffer with the data in the string buffer
** If bPeek == TRUE, The data is not removed from the buffer
** Returns: < 0 on error
** 0 if buffer is empty
** > 0 if copy was sucessful
*/
{
	unsigned int blen = length;

	if (blen > StrBuf_Length(strbuf))
		blen = StrBuf_Length(strbuf);

	if (!blen)
		return blen;

	/* Copy to passed buffer */
	memcpy(readbuffer,strbuf->string,blen);

	if (!bPeek)
	{
		if (blen == StrBuf_Length(strbuf))
		/* Empty the buffer */
			StrBuf_Empty(strbuf);
		else
		/* Shrink it */
		{
			char *ptr;

            memmove(strbuf->string,&strbuf->string[length],StrBuf_Length(strbuf) - blen);
			ptr = (char*)realloc(strbuf->string,StrBuf_Length(strbuf) - blen);

			if (!ptr)
			/* Unable to re-allocate */
			{
				StrBuf_Empty(strbuf);

				return -1;
			}
			else
			/* Buffer has been shrunk */
			{
				strbuf->length -= length;
				strbuf->string = ptr;
				
			}
		}
	}

	return blen;
}
int	StrBuf_ReadCRLF(StrBuffer *strbuf, char *readbuffer, int length, BOOL bPeek)
/*
** StrBuf_ReadCRLF
** Reads the specified string buffer for the next CR, LF, or CRLF-terminated string
** Returns: Length of buffer data copied, 0 if either there is no CRLF or length
** is too short
*/
{
    int rlen = 0, count = 0, end = 0;
	BOOL bExit = FALSE;

	while (!bExit)
	{
		if ((unsigned int)count > StrBuf_Length(strbuf) || count > length)
		{
			bExit = TRUE;
			rlen = 0;
		}
		else
		{
			if (strbuf->string[count] == '\r')
			{
				if (StrBuf_Length(strbuf) != (unsigned)count && strbuf->string[count + 1] == '\n')
				/* We have a CRLF */
					end = count + 2;
				else
				/* We have a CR by itself */
					end = count + 1;
			}
			else if (strbuf->string[count] == '\n')
			/* We have a LF by itself */
				end = count + 1;
			else
			/* Increment our return length */
				rlen++;

			if (end)
			{
				/* Read data into supplied buffer, and take our CR/LF */
				StrBuf_Read(strbuf,readbuffer,end,bPeek);

				readbuffer[end - 1] = 0;

				if (end == count + 2)
				/* Take out CR */
					readbuffer[end - 2] = 0;

				bExit = TRUE;
			}
			else
				count++;
		}
	}

	return rlen;
}