/*
** client.h
**
** Contains header information for clients to server
*/

#ifndef __CLIENT_H__
#define __CLIENT_H__

#include <stdarg.h>
#include "messages.h"
#include "numeric.h"
#include "lookup.h"
#include "strbuf.h"
#include "hash.h"
#include "..\Common Files\settings.h"

/* Defines */
#define			CHANNEL_HASHSIZE					32003

#define			CLIENT_MAXMESSAGEBURST				5
#define			CLIENT_HASHSIZE						32003

#define			SERVER_HASHSIZE						103

/* Client macros */
#define			Client_IsUser(client)				(client->user ? TRUE : FALSE)
#define			Client_IsServer(client)				(client->user ? FALSE : TRUE)
#define			Client_Nickname(client)				(client->user->nickname[0] ? client->user->nickname : "*")
#define			Client_IsLocal(client)				(client->hops == 1)
#define			Client_Invisible(client)			(client->modeflag & CLIENT_MODE_INVISIBLE)
#define			Client_IsAdmin(client)				(client->modeflag & CLIENT_MODE_ADMIN)
#define			Client_IsSysop(client)				(client->modeflag & CLIENT_MODE_SYSOP)
#define			Client_IsGagged(client)				(client->modeflag & CLIENT_MODE_GAG)
#define			Client_IsPriveledged(client)		((client->modeflag & CLIENT_MODE_ADMIN) || (client->modeflag & CLIENT_MODE_SYSOP))

/* Flag/state macros */
#define			Client_Dead(client)					(client->state == CLIENT_STATE_DEAD)
#define			Client_Welcoming(client)			(client->state == CLIENT_STATE_WELCOMING)
#define			Client_Registered(client)			(client->flags & CLIENT_FLAG_REGISTERED ? TRUE : FALSE)
#define			Client_NewLine(client)				(client->flags & CLIENT_FLAG_NEWLINE)
#define			Client_NoNewLine(client)			(!(client->flags & CLIENT_FLAG_NEWLINE))


/* Other macros */
#define			Server_Description(s_client)		s_client->server->description

/* Function prototypes */

void			Client_AcceptNew(SOCKET fdListener);
void			Client_Disconnect(CLIENT_STRUCT *client);
void			Client_Destroy(CLIENT_STRUCT *client);
void			Client_SendError(CLIENT_STRUCT *client, BOOL bCloseOnSend, const char *string, ...);
void			Client_SendErrorNumber(CLIENT_STRUCT *client, BOOL bCloseOnSend, const char *errstr);
void			Client_SendToOne(CLIENT_STRUCT *client,BOOL bCloseOnSend, const char *string, ...);
void			Client_SendLusers(CLIENT_STRUCT *client);
void			Client_SendWelcome(CLIENT_STRUCT *client);
void			Client_SendMOTD(CLIENT_STRUCT *client);
void			Client_SendList(CLIENT_STRUCT *client, BOOL bListX, const char *szParameters);
void			Client_SendNumericToOne(CLIENT_STRUCT *client, int numeric, const char *data);
void			Client_SendToAllLocal(BOOL bCloseOnSend, const char *string, ...);
void			Client_FlushBuffer(CLIENT_STRUCT *client);
int				Client_ReadPacket(CLIENT_STRUCT* client, FD_SET *pread_set);
int				Client_Parse(CLIENT_STRUCT *client, char *message, int length);
unsigned int	Client_GetIdle(CLIENT_STRUCT *c_target);
int				Client_GetWhoisChannels(CLIENT_STRUCT *csAsking, CLIENT_STRUCT *csTarget, char *pszOutputBuffer);
BOOL			Client_IsOnChannel(CLIENT_STRUCT *csUser, CHANNEL_STRUCT *chChannel, DWORD *pdwPriveledge);
void			Server_Broadcast(CLIENT_STRUCT *c_exclude_server, const char *message, ...);
void			Server_BroadcastFromUser(CLIENT_STRUCT *csUser, const char *message, ...);
CLIENT_STRUCT	*User_GetServer(CLIENT_STRUCT *c_user);
CLIENT_STRUCT	*User_Find(const char *nickname);
void			Parse_UserList(const char *szUserList, LINKED_LIST_STRUCT *llUserHead);
CLIENT_STRUCT	*Server_HashFind(const char *servername);
void			User_GetModeString(CLIENT_STRUCT *client, char *pszStringOutput, BOOL bOmitGagMode);
int				User_GetCommonChannels(CLIENT_STRUCT *client, CLIENT_STRUCT *csTarget, char *szChannelBuffer, LINKED_LIST_STRUCT *llChannelHead);
void			User_BroadcastToAllLocalsInAllChannels(CLIENT_STRUCT *csUser, CLIENT_STRUCT *csExcludeUser, char *szMessage, ...);

/* External variables */
extern			SERVER_CONTROL_STRUCT scs;
extern			INFOSTRUCTSETTINGS SettingsInfo;

/* External functions */
extern int		Message_Execute();
extern void		Serverlist_ChangeStatus(const char*, BOOL);

#endif		/* __CLIENT_H__ */