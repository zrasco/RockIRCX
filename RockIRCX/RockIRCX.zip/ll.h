/*
** ll.h
**
** Contains header information for all linked list information & functions
*/

#ifndef __LL_H__
#define __LL_H__

#include "structs.h"

/* Function prototypes */
LINKED_LIST_STRUCT			*LL_Add(LINKED_LIST_STRUCT *head, void *data);
LINKED_LIST_STRUCT			*LL_AddNoCheck(LINKED_LIST_STRUCT *head, void *data);
LINKED_LIST_STRUCT			*LL_Find(LINKED_LIST_STRUCT *head, void *data);
void						LL_Clear(LINKED_LIST_STRUCT *head);
void						*LL_Remove(LINKED_LIST_STRUCT *head, void *data);

#endif		/* __LL_H__ */