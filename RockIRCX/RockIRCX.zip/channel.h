/*
** channel.h
**
** Contains header information relating to channels
*/

#ifndef __CHANNEL_H__
#define __CHANNEL_H__

#include "messages.h"
#include "hash.h"
#include "structs.h"
#include "..\Common Files\settings.h"

/* External variables */
extern HWND						hMain;
extern HWND						hStatus;
extern SERVER_CONTROL_STRUCT	scs;
extern INFOSTRUCTSETTINGS		SettingsInfo;
extern HASH_TABLE_STRUCT		HT_Channel;
extern HASH_TABLE_STRUCT		HT_User;
extern HASH_TABLE_STRUCT		HT_Server;

/* Defines */
#define				Channel_Limit(channel)						(channel->dwLimit ? channel->dwLimit : SettingsInfo.isChannel.defaultlimit)
#define				Channel_InviteOnly(channel)					(channel->dwModes & CHANNELMODE_INVITE ? TRUE : FALSE)
#define				Channel_Full(channel)						(channel->dwUsers >= Channel_Limit(channel) ? TRUE : FALSE)
#define				Channel_HasMemberkey(channel)				(channel->szPropMemberkey[0] ? TRUE : FALSE)
#define				Channel_AccessFull(channel)					(channel->dwAccessEntries >= SettingsInfo.isSecurity.max_access ? TRUE : FALSE)
#define				Channel_HasTopic(channel)					(channel->szPropTopic[0] ? TRUE : FALSE)
#define				Channel_IsLocal(channel)					(channel->szName[0] == '&' ? TRUE : FALSE)
#define				Channel_IsPublic(channel)					(channel->dwModes & CHANNELMODE_PUBLIC)
#define				Channel_NoExtern(channel)					(channel->dwModes & CHANNELMODE_NOEXTERN)
#define				Channel_Moderated(channel)					(channel->dwModes & CHANNELMODE_MODERATED)

/* Function prototypes */
CHANNEL_STRUCT		*Channel_Find(char *szChannelName);
CHANNEL_STRUCT		*Channel_Create(char *szChannelName);
CHANNEL_STRUCT		*Channel_CreateDefault(char *szChannelName);
int					Channel_AddUser(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser, DWORD dwUsermodes);
void				Channel_AddUsersFromList(CHANNEL_STRUCT *chChannel, const char *szUserlist);
void				Channel_DeleteAllUsers(CHANNEL_STRUCT *chChannel);
int					Channel_DeleteUser(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser);
void				Channel_Cleanup(CHANNEL_STRUCT *chChannel);
void				Channel_BroadcastToLocal(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser, CLIENT_STRUCT *csExcludeUser, char *szMessage, ...);
void				Channel_SendNames(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser);
int					Channel_CreateUserlist(CHANNEL_STRUCT *chChannel, char *pszStringOutput, DWORD dwStringSize);
void				Channel_GetModeString(CHANNEL_STRUCT *chChannel, char *pszStringOutput);
DWORD				Channel_GetModeFlagFromChar(CHANNEL_STRUCT *chChannel, char cMode);
DWORD				Channel_GetModeFlagFromString(CHANNEL_STRUCT *chChannel, const char *szModeString);
DWORD				Channel_GetUserModeFlags(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser);
void				Channel_KickAllLocal(CHANNEL_STRUCT *chChannel, char *szFrom, char *szReason);
void				Parse_ChannelList(const char *szChannelList, LINKED_LIST_STRUCT *llChannelHead);

#endif		/* __CHANNEL_H__ */