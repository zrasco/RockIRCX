/*
** channel.cpp
**
** This file contains all the code related to tasks related to working with channels.
*/

#include "channel.h"

CHANNEL_STRUCT *Channel_Find(char *szChannelName)
/*
** Channel_Find()
** This function will attempt to locate the channel specified
** Returns NULL if channel was not found
*/
{
	CHANNEL_STRUCT *cret = NULL, *channel = NULL;
	HASH_FIND_STRUCT FindInfo;
	LINKED_LIST_STRUCT *curr = NULL;

	/* Find our channel in the hash table */
	FindInfo.textkey = szChannelName;
	FindInfo.data = NULL;

	Hash_Find(&HT_Channel,&FindInfo,HASH_NOKEY);

	if (FindInfo.found)
	/* The channel possibly exists */
	{
		curr = &(FindInfo.found->chainhead);

		while (curr->next)
		{
			curr = curr->next;

			channel = (CHANNEL_STRUCT*)curr->data;

			if (stricmp(szChannelName,channel->szName) == 0)
			/* Channel has been found */
			{
				cret = channel;
				break;
			}
		}
	}

	return cret;
}

CHANNEL_STRUCT *Channel_Create(char *szChannelName)
/*
** Channel_Create()
** Creates a blank channel, and adds it to the lists
** Returns NULL if channel already exists
*/
{
	CHANNEL_STRUCT *cret = NULL;

	cret = Channel_Find(szChannelName);

	if (!cret)
	/* Create a new channel */
	{
		cret = (CHANNEL_STRUCT*)calloc(1,sizeof(CHANNEL_STRUCT));

		/* Let's name our channel */
		strcpy(cret->szName,szChannelName);		

		/* Add our channel to the global list & to the global hash table */
		LL_Add(&(scs.llChannelHead),cret);
		Hash_Add(&HT_Channel,cret->szName,cret);

		scs.lusers.nChannels++;
		SettingsInfo.isStatus.globalchannels++;
	}
	else
		ODS("Channel_Create() called on a channel which exists already(%s)!",szChannelName);

	return cret;
}

CHANNEL_STRUCT *Channel_CreateDefault(char *szChannelName)
/*
** Channel_CreateDefault()
** Creates a regular ol' channel with default modes, and adds it to the lists
** Returns NULL if channel already exists
*/
{
	CHANNEL_STRUCT *cret = NULL;

	cret = Channel_Find(szChannelName);

	if (!cret)
	/* Create a new channel */
	{
		cret = (CHANNEL_STRUCT*)calloc(1,sizeof(CHANNEL_STRUCT));

		/* Let's name our channel */
		strcpy(cret->szName,szChannelName);

		/* Default public channel with mode of "+nt" */
		cret->dwModes = CHANNELMODE_PUBLIC | CHANNELMODE_TOPICOP | CHANNELMODE_NOEXTERN;

		/* Set creation time */
		cret->dwPropCreationTime = time(NULL);

		/* Add our channel to the global list & to the global hash table */
		LL_Add(&(scs.llChannelHead),cret);
		Hash_Add(&HT_Channel,cret->szName,cret);

		scs.lusers.nChannels++;
		SettingsInfo.isStatus.localchannels++;
		SettingsInfo.isStatus.globalchannels++;
	}

	return cret;
}

int Channel_AddUser(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser, DWORD dwUsermodes)
/*
** Channel_AddUser()
** Adds the user to the channel and lets all the other members know about it.
** THIS WILL ADD THE USER NO MATTER WHAT! CHECKING MUST BE DONE BEFORE CALLING THIS!
** THIS INCLUDES ACCESS/OWNERKEY CHECKING! IT WILL ADD AN OWNER IF SPECIFIED IN THE FLAGS
** Returns -1 if user is already on channel, otherwise returns 0
*/
{
	LINKED_LIST_STRUCT *llUser = LL_Find(&(chChannel->llUserHead),csUser);

	if (!llUser)
	/* Add this user */
	{
		/* Add user to the list of members in the channel */
		chChannel->dwUsers++;
		LL_Add(&(chChannel->llUserHead),csUser);
		LL_AddNoCheck(&(chChannel->llUserModeHead),(void*)dwUsermodes);

		/* Add this channel to the list of channels user is on */
		LL_Add(&(csUser->user->llChannelHead),(void*)(chChannel));

		/* Send JOIN message(to all), topic, topic set date, names list, onjoin, etc... to user */
		Channel_BroadcastToLocal(chChannel,csUser,NULL,MSG_JOIN " :%s",chChannel->szName);
		Server_BroadcastFromUser(csUser,TOK_JOIN " :%s",chChannel->szName);

		if (Client_IsLocal(csUser))
		{
			/* Send topic */
			if Channel_HasTopic(chChannel)
				Client_SendToOne(csUser,FALSE,":%s %3.3d %s %s :%s",SettingsInfo.isGeneral.servername,332,Client_Nickname(csUser),chChannel->szName,chChannel->szPropTopic);

			/* Send names */
			Channel_SendNames(chChannel,csUser);
		}

		/* Broadcast user mode change(if any) to all other members */
		if (dwUsermodes & CHANNEL_PRIVELEDGE_OWNER)
		{
			Channel_BroadcastToLocal(chChannel,csUser,csUser,MSG_MODE " %s +q %s",chChannel->szName,csUser->user->nickname);
			Server_BroadcastFromUser(csUser,TOK_MODE " %s +q %s",chChannel->szName,csUser->user->nickname);
		}
		else if (dwUsermodes & CHANNEL_PRIVELEDGE_HOST)
		{
			Channel_BroadcastToLocal(chChannel,csUser,csUser,MSG_MODE " %s +o %s",chChannel->szName,csUser->user->nickname);
			Server_BroadcastFromUser(csUser,TOK_MODE " %s +o %s",chChannel->szName,csUser->user->nickname);
		}
		else if (dwUsermodes & CHANNEL_PRIVELEDGE_VOICE)
		{
			Channel_BroadcastToLocal(chChannel,csUser,csUser,MSG_MODE " %s +v %s",chChannel->szName,csUser->user->nickname);
			Server_BroadcastFromUser(csUser,TOK_MODE " %s +v %s",chChannel->szName,csUser->user->nickname);
		}
	}

	return -1;
}

void Channel_AddUsersFromList(CHANNEL_STRUCT *chChannel, const char *szUserlist)
/*
** Channel_AddUsersFromList
** Adds the users specified in the list, but does not broadcast joins etc
** Intended to be used in response to NJOIN commands
*/
{
	char szNextUser[64], cPriveledge;
	int tokens = numtok(szUserlist,32);
	int index;
	DWORD dwPriveledge;
	CLIENT_STRUCT *csUser;

	for (index = 0; index <= tokens; index++)
	/* Get our users */
	{
		/* Get our next user & their priveledge */
		gettok(szNextUser,szUserlist,index,32);
		cPriveledge = szNextUser[0];

		if (cPriveledge == '.')
			dwPriveledge = CHANNEL_PRIVELEDGE_OWNER;
		else if (cPriveledge == '@')
			dwPriveledge = CHANNEL_PRIVELEDGE_HOST;
		else if (cPriveledge == '+')
			dwPriveledge = CHANNEL_PRIVELEDGE_VOICE;
		else
			dwPriveledge = 0x00000000;

		if (dwPriveledge)
		/* Take our priveledge marker out before we search */
			strcpy(szNextUser,&szNextUser[1]);

		csUser = User_Find(szNextUser);

		if (csUser)
		/* We should be able to find EVERY user on the list */
			Channel_AddUser(chChannel,csUser,dwPriveledge);
		else
		/* If not, something has gone horribly wrong */
			ODS("Channel_AddUsersFromList() attempting to add an invalid user(%s)!",szNextUser);

	}

}

void Channel_DeleteAllUsers(CHANNEL_STRUCT *chChannel)
/*
** Channel_DeleteAllUsers()
** Deletes all users from the channel list!
*/
{
	while (chChannel->llUserHead.next)
		Channel_DeleteUser(chChannel,(CLIENT_STRUCT*)chChannel->llUserHead.next->data);
}

int Channel_DeleteUser(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser)
/*
** Channel_DeleteUser()
** Deletes a user from the channel list, but needs to be kicked out somehow first
** This function will not issue a PART QUIT KICK or KILL on behalf of the user!
*/
{
	LINKED_LIST_STRUCT *llPrevUser = NULL, *llUser = &(chChannel->llUserHead);
	LINKED_LIST_STRUCT *llPrevUserMode = NULL, *llUserMode = &(chChannel->llUserModeHead);

	/* Remove this channel from the list of channels user is on */
	LL_Remove(&(csUser->user->llChannelHead),(void*)(chChannel));

	/* Update our channel user count */
	chChannel->dwUsers--;

	while (llUser->next)
	/* Go thru channel list and find the user/user modes */
	{
		llPrevUser = llUser; llPrevUserMode = llUserMode;
		llUser = llUser->next;
		llUserMode = llUserMode->next;

		if ((CLIENT_STRUCT*)(llUser->data) == csUser)
		/* Found 'em! */
		{
			/* Remove from the list */
			llPrevUser->next = llUser->next;
			llPrevUserMode->next = llUserMode->next;

			free(llUser);
			free(llUserMode);

			return 0;
		}
	}

	return 0;
}

void Channel_Cleanup(CHANNEL_STRUCT *chChannel)
/*
** Channel_Cleanup()
** Deallocates and clears the channel, ONLY CALL WHEN NOBODY IS IN THERE!
*/
{
	/* Remove from all lists */
	Hash_Delete(&HT_Channel,chChannel->szName,chChannel);
	LL_Remove(&(scs.llChannelHead),chChannel);

	/* Update our counters */
	scs.lusers.nChannels--;
	SettingsInfo.isStatus.localchannels--;
	SettingsInfo.isStatus.globalchannels--;

	free(chChannel);

}

void Channel_BroadcastToLocal(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser, CLIENT_STRUCT *csExcludeUser, char *szMessage, ...)
/*
** Channel_BroadcastToLocal()
** Sends the message for specified user to everyone on the channel
** If csExcludeUser is specified, it will not send to them!
*/
{
	LINKED_LIST_STRUCT *llUser = &(chChannel->llUserHead);
	LINKED_LIST_STRUCT *llUsermode = &(chChannel->llUserModeHead);
	CLIENT_STRUCT *csNext = NULL;
	DWORD dwUsermode = 0;

	va_list vArgs;
	char buf[2048];

	va_start(vArgs,szMessage);
	vsprintf(buf,szMessage,vArgs);
	va_end(vArgs);

	/* Send the message to locals and pass it along */
	while (llUser->next)
	{
		llUser = llUser->next;
		llUsermode = llUsermode->next;
		dwUsermode = (DWORD)llUsermode->data;

		csNext = (CLIENT_STRUCT*)llUser->data;

		if (csNext != csExcludeUser)
		/* Send to all but this person */
		{
			if (csNext == csUser || SettingsInfo.isGeneral.dns_masktype == SETTINGS_GENERAL_DONTMASK ||
				( SettingsInfo.isGeneral.dns_masktype == SETTINGS_GENERAL_XOUT &&
				(dwUsermode & CHANNEL_PRIVELEDGE_OWNER ||
				dwUsermode & CHANNEL_PRIVELEDGE_HOST)))
			/* If masking on, only send whole hostmask to people who are owners/hosts */
			{
				if (Client_IsLocal(csNext))
					Client_SendToOne(csNext,FALSE,":%s!~%s@%s %s",csUser->user->nickname,csUser->user->username,csUser->hostname,buf);
			}
			else
			/* Send it masked */
			{
				Client_SendToOne(csNext,FALSE,":%s!~%s@%s %s",csUser->user->nickname,csUser->user->username,csUser->hostmask,buf);
			}
		}
	}

	/* Send the message(unmasked) to all other servers */
	//Server_Broadcast(csUser->servernext,":%s!~%s@%s %s",csUser->user->nickname,csUser->user->username,csUser->hostname,buf);
}

void Channel_SendNames(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser)
/*
** Channel_SendNames()
** Sends a NAMES list for a channel to the specified user, and performs all checking
*/
{
	char namesbuf[2048], namesbuflist[2048];

	/* TODO: Check channel mode vs if user is on channel vs invisible people, etc... */
	/* TEMP: Just have one huge 353 for now */
	sprintf(namesbuf,":%s %d %s = %s :",SettingsInfo.isGeneral.servername,
		RPL_NAMREPLY,
		csUser->user->nickname,
		chChannel->szName);

	Channel_CreateUserlist(chChannel,namesbuflist,sizeof(namesbuflist));
	strcat(namesbuf,namesbuflist);

	Client_SendToOne(csUser,FALSE,namesbuf);

	/* End of /NAMES */
	Client_SendToOne(csUser,FALSE,":%s %d %s %s :End of /NAMES list",
		SettingsInfo.isGeneral.servername,
		RPL_ENDOFNAMES,
		csUser->user->nickname,
		chChannel->szName);
}

int Channel_CreateUserlist(CHANNEL_STRUCT *chChannel, char *pszStringOutput, DWORD dwStringSize)
/*
** Channel_CreateUserlist()
** Fills the specified string with a list of users for the channel
** Returns -1 if the list needed to be truncated
*/
{
	LINKED_LIST_STRUCT *llUser = &(chChannel->llUserHead);
	LINKED_LIST_STRUCT *llUsermode = &(chChannel->llUserModeHead);
	char *buf = (char*)calloc(1,dwStringSize);
	DWORD len = 0;
	DWORD dwUsermode = 0;
	char namebuf[128];

	while (llUser->next)
	/* Go thru list and start addin em! */
	{
        llUser = llUser->next;
		llUsermode = llUsermode->next;
		dwUsermode = (DWORD)llUsermode->data;

		/* Add our mode */
		if (dwUsermode & CHANNEL_PRIVELEDGE_OWNER)
			strcpy(namebuf,".");
		else if (dwUsermode & CHANNEL_PRIVELEDGE_HOST)
			strcpy(namebuf,"@");
		else if (dwUsermode & CHANNEL_PRIVELEDGE_VOICE)
			strcpy(namebuf,"+");
		else
			namebuf[0] = 0;

		/* Add our user */
		strcat(namebuf,((CLIENT_STRUCT*)llUser->data)->user->nickname);
		strcat(namebuf," ");

		len += strlen(namebuf);

		if (len >= dwStringSize)
		/* List supplied not big enough! */
		{
			free(buf);
			return -1;
		}
		else
		/* Add to the list */
			strcat(buf,namebuf);
	}

	strcpy(pszStringOutput,buf);

	free(buf);

	return 0;
}

void Channel_GetModeString(CHANNEL_STRUCT *chChannel, char *pszStringOutput)
/*
** Channel_GetModeString()
** Takes the modes of the channel and creates a string with it
** The string is outputted to the pointer passed in pszStringOutput
*/
{
	char buf[256];

	strcpy(buf,"+");

	if (chChannel->dwModes & CHANNELMODE_NOEXTERN)
		strcat(buf,"n");

	if (chChannel->dwModes & CHANNELMODE_TOPICOP)
		strcat(buf,"t");

	/* Return our mode string */
	strcpy(pszStringOutput,buf);
}

DWORD Channel_GetModeFlagFromChar(CHANNEL_STRUCT *chChannel, char cMode)
{
	switch (cMode)
	/* What we got? */
	{
		case 't':
			return CHANNELMODE_TOPICOP;
		break;
		case 'u':
			return CHANNELMODE_KNOCK;
		break;
		case 'w':
			return CHANNELMODE_NOWHISPER;
		break;
		case 'm':
			return CHANNELMODE_MODERATED;
		break;
		case 'n':
			return CHANNELMODE_NOEXTERN;
		break;
		case 'i':
			return CHANNELMODE_INVITE;
		break;
		case 'f':
			return CHANNELMODE_NOFORMAT;
		break;
		case 'x':
			return CHANNELMODE_AUDITORIUM;
		break;
		case 'r':
			return CHANNELMODE_REGISTERED;
		break;
		case 'z':
			return CHANNELMODE_SERVICE;
		break;
		case 'a':
			return CHANNELMODE_AUTHONLY;
		break;
		case 'd':
			return CHANNELMODE_CLONEABLE;
		break;
		case 'e':
			return CHANNELMODE_CLONE;
		break;
		default:
			return 0x00000000;
		break;
	}
}

DWORD Channel_GetModeFlagFromString(CHANNEL_STRUCT *chChannel, const char *szModeString)
/*
** Channel_GetModeFlag()
** Converts and returns the specified mode string into a set of mode flags
*/
{
	DWORD dwRetval = 0;
	int index;

	for (index = 0; szModeString[index]; index++)
	/* Parse our mode list */
		dwRetval |= Channel_GetModeFlagFromChar(chChannel, szModeString[index]);

	return dwRetval;
}

DWORD Channel_GetUserModeFlags(CHANNEL_STRUCT *chChannel, CLIENT_STRUCT *csUser)
/*
** Channel_GetUserModes()
** Returns mode flag bit field for the specified user, on the specified channel
*/
{
	LINKED_LIST_STRUCT *llUser = &(chChannel->llUserHead);
	LINKED_LIST_STRUCT *llUserMode = &(chChannel->llUserModeHead);

	while (llUser->next)
	/* Go through the user list of this channel */
	{
		llUser = llUser->next;
		llUserMode = llUserMode->next;

		if (
			((CLIENT_STRUCT*)(llUser->data)) == csUser
			)
		/* Found our user! */
		{
			return (DWORD)llUserMode->data;
		}
	}

	/* 0 if user is not in channel */
	return 0;
}

void Channel_KickAllLocal(CHANNEL_STRUCT *chChannel, char *szFrom, char *szReason)
/*
** Channel_KickAllLocal()
** Kicks everyone out of the channel! Only use in channel collision
** as this function WILL NOT remove them from the list! A subsequent call to
** Channel_DeleteAllUsers() should do that!
** REPEAT: THIS FUNCTION WILL NOT DELETE THEM FROM THE LIST!!!! WILL NOT!!!!
*/
{
	LINKED_LIST_STRUCT *llUser = &(chChannel->llUserHead);
	CLIENT_STRUCT *csUser = NULL;

	while (llUser->next)
	/* Go through our list */
	{
		llUser = llUser->next;
		csUser = (CLIENT_STRUCT*)llUser->data;

		if (Client_IsLocal(csUser))
		/* Now the fun begins... :) */
		{
			if (szReason)
			Client_SendToOne(csUser,FALSE,":%s " MSG_KICK " %s %s :%s",
				szFrom,
				chChannel->szName,
				Client_Nickname(csUser),
				szReason);
			else
			Client_SendToOne(csUser,FALSE,":%s " MSG_KICK " %s %s :",
				szFrom,
				chChannel->szName,
				Client_Nickname(csUser));

		}
	}
}

void Parse_ChannelList(const char *szChannelList, LINKED_LIST_STRUCT *llChannelHead)
/*
** Parse_ChannelList()
** Takes a list of channels and puts them in the specified linked list.
** Any channels which do not exist will be placed in the list as the value NULL
*/
{
	CHANNEL_STRUCT *chChannel = NULL;

	int count, tokens = numtok(szChannelList,',');
	char chbuf[512];

	llChannelHead->next = NULL; llChannelHead->data = NULL;

	for (count = 1; count <= tokens; count++)
	/* Loop through the channels seperated by commas */
	{
		chChannel = Channel_Find(gettok(chbuf,szChannelList,count,','));

		if (chChannel == NULL)
		/* Add our NULL entry */
            LL_AddNoCheck(llChannelHead,(void*)NULL);
		else
		/* Add our channel, but we don't want duplicate entries */
			LL_Add(llChannelHead,(void*)chChannel);
	}
}