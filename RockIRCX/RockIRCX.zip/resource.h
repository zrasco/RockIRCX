//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RockIRCX.rc
//
#define IDD_DIALOG3                     2
#define IDD_ABOUT                       3
#define IDI_ICON3                       4
#define IDB_INFOP                       5
#define IDB_BITMAP2                     5
#define IDB_INFO                        6
#define IDB_WARNING                     9
#define IDB_ERROR                       10
#define IDB_OK                          12
#define IDB_BITMAP3                     13
#define IDB_BITMAP1                     14
#define IDC_TRAYICON                    101
#define IDD_ROCKIRCX_DIALOG             102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_EDIT1                       106
#define IDI_ROCKIRCX                    107
#define IDI_SMALL                       108
#define IDC_ROCKIRCX                    109
#define IDC_EDITLOCALUSERS              110
#define IDC_EDIT2                       111
#define IDC_EDITLOCALUSERSMAX           112
#define IDC_EDIT3                       113
#define IDC_EDITGLOBALUSERS             114
#define IDC_EDIT4                       115
#define IDC_EDITGLOBALUSERSMAX          116
#define IDC_EDIT5                       117
#define IDC_EDITLOCALCHANNELS           118
#define IDC_EDIT6                       119
#define IDC_EDITGLOBALCHANNELS          120
#define IDC_EDIT7                       121
#define IDC_EDITDOWNLOAD                122
#define IDC_EDIT8                       123
#define IDC_EDITUPLOAD                  124
#define IDC_EDIT9                       125
#define IDC_EDITPORT                    126
#define IDC_SCROLLBAR1                  127
#define IDR_MAINFRAME                   128
#define IDD_MAIN                        129
#define IDD_STATUS                      130
#define IDD_SERVERS                     131
#define IDD_LOG                         132
#define IDC_VSPORT                      133
#define IDC_LIST1                       134
#define IDC_LVSERVERS                   135
#define IDC_BUTTON1                     136
#define IDC_BTNAPPLY                    137
#define IDC_BUTTON2                     138
#define IDC_BTNCLOSE                    139
#define IDC_BUTTON3                     140
#define IDC_BTNSHUTDOWN                 141
#define IDC_MYICON                      1000
#define IDC_LBLOG                       1015
#define IDC_TAB1                        1016
#define IDC_TABMAIN                     1017
#define IDC_RADIO1                      1018
#define IDC_TVSERVERS                   1020
#define ID_BITMAPS                      2000
#define IDB_SERVERNOTOK                 2100
#define IDB_SERVEROK                    2101
#define IDB_SERVERINBOUND               2102
#define IDB_SERVEROUTBOUND              2103
#define IDM_SHOW                        32774
#define IDM_CONNECT                     32775
#define IDM_SHUTDOWN                    32776
#define ID_SHOWROCKIRCX_G               32778
#define ID_G_G                          32779
#define ID_SHOWROCKIRCX_R               32780
#define ID_SHOWROCKIRCX                 32781
#define IDM_SM_CONNECTED                32782
#define IDM_SM_DISCONNECTED             32783
#define IDC_STATIC                      4294967295

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        16
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           32877
#endif
#endif
