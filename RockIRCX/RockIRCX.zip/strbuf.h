/*
** strbuf.h
**
** Contains all header information for string buffering functions
*/

#ifndef __STRBUF_H__
#define __STRBUF_H__

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdlib.h>

typedef struct StrBuffer
{
	char				*string;							/* Pointer to buffer */
	unsigned int		length;								/* Length of string */
} StrBuffer;

#define StrBuf_IsEmpty(sb)					((sb)->length == 0)
#define StrBuf_Length(sb)					((sb)->length)
#define	StrBuf_String(sb)					((sb)->string)

/* String buffer functions */																
void		StrBuf_Empty(StrBuffer *strbuf);												/* Empty the referenced buffer */
int			StrBuf_Add(StrBuffer *strbuf, const char* string, int length);					/* Add text to end of buffer */
int			StrBuf_Delete(StrBuffer *strbuf, int mark);										/* Delete text from string buffer up to # passed */
int			StrBuf_Read(StrBuffer *strbuf, char *readbuffer, int length, BOOL bPeek);		/* Read text from buffer */
int			StrBuf_ReadCRLF(StrBuffer *strbuf, char *readbuffer, int length, BOOL bPeek);	/* Read next CR, LF, or CRLF-terminated string */

#endif		/* __STRBUF_H__ */